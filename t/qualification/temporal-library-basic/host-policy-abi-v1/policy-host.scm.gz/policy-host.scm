(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host::timestamp
    1791201746)
  (begin
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
      (let ((__tmp6254 (list)) (__tmp6253 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'policy-host-state
         __tmp6254
         '(current revisions)
         __tmp6253
         '#f)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#make-policy-host-state
      (lambda _%$args3426%_
        (apply make-instance
               poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
               _%$args3426%_)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-current
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-revisions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-current-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-revisions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-current
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-revisions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-current-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-revisions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host
      (lambda ()
        (let ((__obj6251
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp6256
                 (list (cons 'kind
                             (let ((__tmp6257
                                    (lambda (_%self3414%_)
                                      'poo-flow.temporal-causality.policy-host.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp6257)))
                       (cons 'private-runtime-state
                             (let ((__tmp6258
                                    (lambda (_%self3421%_)
                                      (let ((__tmp6260
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value)))
                                            (__tmp6259
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value))))
                                        (declare (not safe))
                                        (##structure
                                         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                                         __tmp6260
                                         __tmp6259)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp6258)))))
                (__tmp6255 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp6256
             __tmp6255
             __obj6251))
          __obj6251)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#state
      (lambda (_%host3399%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%host3399%_
                    'clan/poo/object#object::t))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot? _%host3399%_ 'kind))
                 (eq? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%host3399%_ 'kind))
                      'poo-flow.temporal-causality.policy-host.v1)
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot?
                    _%host3399%_
                    'private-runtime-state))
                 (let ((__tmp6261
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%host3399%_
                           'private-runtime-state))))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp6261
                    'poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid policy host capability")))
        (let ()
          (declare (not safe))
          (clan/poo/object#.ref _%host3399%_ 'private-runtime-state))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#instant-row
      (lambda (_%x3395%_)
        (let ((__tmp6262
               (lambda (_%s3397%_)
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%x3395%_ _%s3397%_)))))
          (declare (not safe))
          (##map __tmp6262
                 '(identity
                   domain-identity
                   coordinate
                   provenance-identity
                   modality)))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#canonical-policy
      (lambda (_%p3391%_)
        (let ((_%canonical3393%_
               (let ((__tmp6266
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3391%_ 'identity)))
                     (__tmp6265
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3391%_ 'revision-identity)))
                     (__tmp6264
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3391%_ 'start)))
                     (__tmp6263
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3391%_ 'end))))
                 (declare (not safe))
                 (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-policy
                  __tmp6266
                  __tmp6265
                  __tmp6264
                  __tmp6263))))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3391%_ 'semantic-digest))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%canonical3393%_
                         'semantic-digest)))
              '#!void
              (let () (declare (not safe)) (error '"forged host policy")))
          _%canonical3393%_)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-refresh!
      (lambda (_%host3163%_
               _%policy3164%_
               _%generation-value3165%_
               _%effective-value3166%_)
        (if (and (exact-integer? _%generation-value3165%_)
                 (<= '0 _%generation-value3165%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid host policy generation")))
        (let* ((_%s3168%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#state
                 _%host3163%_))
               (_%owned3170%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#canonical-policy
                 _%policy3164%_))
               (_%time-value3172%_
                (let ((__tmp6271
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3166%_
                          'identity)))
                      (__tmp6270
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3166%_
                          'domain-identity)))
                      (__tmp6269
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3166%_
                          'coordinate)))
                      (__tmp6268
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3166%_
                          'provenance-identity)))
                      (__tmp6267
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3166%_
                          'modality))))
                  (declare (not safe))
                  (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-instant
                   __tmp6271
                   __tmp6270
                   __tmp6269
                   __tmp6268
                   __tmp6267)))
               (_%id3174%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%owned3170%_ 'identity)))
               (_%current3176%_
                (##structure-ref
                 _%s3168%_
                 '1
                 poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                 '#f))
               (_%history3178%_
                (##structure-ref
                 _%s3168%_
                 '2
                 poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                 '#f))
               (_%old3207%_
                (let* ((_%h3180%_ _%current3176%_)
                       (_%key3183%_ _%id3174%_)
                       (_%h3187%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h3180%_)))
                       (_%h3189%_ _%h3187%_))
                  (declare (not safe))
                  (__hash-get _%h3189%_ _%key3183%_)))
               (_%revision-key3209%_
                (list _%id3174%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%owned3170%_
                         'revision-identity))))
               (_%original3233%_
                (let* ((_%h3211%_ _%history3178%_)
                       (_%key3214%_ _%revision-key3209%_)
                       (_%h3218%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h3211%_)))
                       (_%h3220%_ _%h3218%_))
                  (declare (not safe))
                  (__hash-get _%h3220%_ _%key3214%_))))
          (if (and (eq? (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%time-value3172%_ 'modality))
                        'observed)
                   (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%time-value3172%_
                              'domain-identity))
                           (let ((__tmp6272
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%owned3170%_
                                     'start))))
                             (declare (not safe))
                             (clan/poo/object#.ref
                              __tmp6272
                              'domain-identity))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"host policy clock domain or modality mismatch")))
          (if _%original3233%_
              (if (equal? (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%original3233%_
                             'semantic-digest))
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%owned3170%_
                             'semantic-digest)))
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"host policy revision identity is immutable")))
              '#!void)
          (if _%old3207%_
              (begin
                (if (and (equal? (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%time-value3172%_
                                    'domain-identity))
                                 (let ((__tmp6273
                                        (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%old3207%_
                                           'effective-at))))
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    __tmp6273
                                    'domain-identity)))
                         (>= (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%time-value3172%_
                                'coordinate))
                             (let ((__tmp6274
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%old3207%_
                                       'effective-at))))
                               (declare (not safe))
                               (clan/poo/object#.ref __tmp6274 'coordinate))))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"host policy clock rollback")))
                (if (or (> _%generation-value3165%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%old3207%_ 'generation)))
                        (and (= _%generation-value3165%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%old3207%_
                                   'generation)))
                             (equal? (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%owned3170%_
                                        'semantic-digest))
                                     (let ((__tmp6275
                                            (let ()
                                              (declare (not safe))
                                              (clan/poo/object#.ref
                                               _%old3207%_
                                               'policy))))
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        __tmp6275
                                        'semantic-digest)))
                             (equal? (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#instant-row
                                      _%time-value3172%_)
                                     (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#instant-row
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%old3207%_
                                         'effective-at))))))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"host policy generation rollback or conflict"))))
              '#!void)
          (if (and (or _%old3207%_
                       (< (let* ((_%h3242%_ _%current3176%_)
                                 (_%h3246%_
                                  (let ()
                                    (declare (not safe))
                                    (cast HashTable::interface _%h3242%_)))
                                 (_%h3248%_ _%h3246%_))
                            (declare (not safe))
                            (__hash-length _%h3248%_))
                          '128))
                   (or _%original3233%_
                       (< (let* ((_%h3264%_ _%history3178%_)
                                 (_%h3268%_
                                  (let ()
                                    (declare (not safe))
                                    (cast HashTable::interface _%h3264%_)))
                                 (_%h3270%_ _%h3268%_))
                            (declare (not safe))
                            (__hash-length _%h3270%_))
                          '128)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"host policy registry capacity exceeded")))
          (let ((_%snapshot3340%_
                 (let ((__obj6252
                        (let ()
                          (declare (not safe))
                          (##structure
                           clan/poo/object#object::t
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp6277
                          (list (cons 'kind
                                      (let ((__tmp6278
                                             (lambda (_%self3298%_)
                                               'poo-flow.temporal-causality.policy-host-snapshot.v1)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6278)))
                                (cons 'policy
                                      (let ((__tmp6279
                                             (lambda (_%self3305%_)
                                               _%owned3170%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6279)))
                                (cons 'generation
                                      (let ((__tmp6280
                                             (lambda (_%self3310%_)
                                               _%generation-value3165%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6280)))
                                (cons 'effective-at
                                      (let ((__tmp6281
                                             (lambda (_%self3315%_)
                                               _%time-value3172%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6281)))
                                (cons 'trust-basis
                                      (let ((__tmp6282
                                             (lambda (_%self3320%_)
                                               'host-registered-policy-snapshot)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6282)))
                                (cons 'source-authenticated?
                                      (let ((__tmp6283
                                             (lambda (_%self3325%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6283)))
                                (cons 'action-authorized?
                                      (let ((__tmp6284
                                             (lambda (_%self3330%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6284)))
                                (cons 'durable?
                                      (let ((__tmp6285
                                             (lambda (_%self3335%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6285)))))
                         (__tmp6276 (list)))
                     (declare (not safe))
                     (clan/poo/object#object:::init!__%
                      '#f
                      '()
                      __tmp6277
                      __tmp6276
                      __obj6252))
                   __obj6252)))
            (let* ((_%h3342%_ _%history3178%_)
                   (_%key3345%_ _%revision-key3209%_)
                   (_%value3348%_ _%owned3170%_)
                   (_%h3352%_
                    (let ()
                      (declare (not safe))
                      (cast HashTable::interface _%h3342%_)))
                   (_%h3354%_ _%h3352%_))
              (declare (not safe))
              (__hash-put! _%h3354%_ _%key3345%_ _%value3348%_))
            (let* ((_%h3367%_ _%current3176%_)
                   (_%key3370%_ _%id3174%_)
                   (_%value3373%_ _%snapshot3340%_)
                   (_%h3377%_
                    (let ()
                      (declare (not safe))
                      (cast HashTable::interface _%h3367%_)))
                   (_%h3379%_ _%h3377%_))
              (declare (not safe))
              (__hash-put! _%h3379%_ _%key3370%_ _%value3373%_))
            _%snapshot3340%_))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-guard
      (lambda (_%host3127%_
               _%expected-generation3128%_
               _%expected-policy-digest3129%_
               _%program3130%_
               _%journal3131%_
               _%as-of3132%_
               _%valid-at3133%_
               _%budget3134%_)
        (let* ((_%s3136%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#state
                 _%host3127%_))
               (_%snapshot3160%_
                (let* ((_%h3138%_
                        (##structure-ref
                         _%s3136%_
                         '1
                         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                         '#f))
                       (_%key3141%_
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%program3130%_
                           'policy-identity)))
                       (_%h3145%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h3138%_)))
                       (_%h3147%_ _%h3145%_))
                  (declare (not safe))
                  (__hash-get _%h3147%_ _%key3141%_))))
          (if (and _%snapshot3160%_
                   (exact-integer? _%expected-generation3128%_)
                   (= _%expected-generation3128%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%snapshot3160%_ 'generation))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"unregistered or stale host policy generation")))
          (let ((__tmp6287
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3160%_ 'policy)))
                (__tmp6286
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3160%_ 'effective-at))))
            (declare (not safe))
            (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-guard
             _%program3130%_
             _%journal3131%_
             _%as-of3132%_
             _%valid-at3133%_
             _%budget3134%_
             __tmp6287
             _%expected-policy-digest3129%_
             __tmp6286)))))))
