(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/src/ffi/temporal-policy::timestamp 1791201769)
  (begin
    (define poo-flow/src/ffi/temporal-policy#host
      (let ()
        (declare (not safe))
        (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host)))
    (define poo-flow/src/ffi/temporal-policy#field
      (lambda (_%x2040%_ _%key2041%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2040%_ 'HashTable::t))
                 (let* ((_%h2043%_ _%x2040%_)
                        (_%k2046%_ _%key2041%_)
                        (_%h2050%_ _%h2043%_)
                        (_%h2052%_ _%h2050%_))
                   (declare (not safe))
                   (__hash-key? _%h2052%_ _%k2046%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"missing policy field" _%key2041%_)))
        (let* ((_%h2064%_ _%x2040%_)
               (_%key2067%_ _%key2041%_)
               (_%default2070%_ absent-obj)
               (_%h2074%_
                (let ()
                  (declare (not safe))
                  (cast HashTable::interface _%h2064%_)))
               (_%h2076%_ _%h2074%_))
          (declare (not safe))
          (__hash-ref__% _%h2076%_ _%key2067%_ _%default2070%_))))
    (define poo-flow/src/ffi/temporal-policy#fields
      (lambda (_%x2017%_ _%names2018%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2017%_ 'HashTable::t))
                 (= (let* ((_%h2020%_ _%x2017%_)
                           (_%h2024%_ _%h2020%_)
                           (_%h2026%_ _%h2024%_))
                      (declare (not safe))
                      (__hash-length _%h2026%_))
                    (length _%names2018%_)))
            '#!void
            (let () (declare (not safe)) (error '"unexpected policy fields")))
        (for-each
         (lambda (_%name2038%_)
           (poo-flow/src/ffi/temporal-policy#field _%x2017%_ _%name2038%_))
         _%names2018%_)))
    (define poo-flow/src/ffi/temporal-policy#instant
      (lambda (_%x2015%_)
        (poo-flow/src/ffi/temporal-policy#fields
         _%x2015%_
         (cons '"identity"
               (cons '"domain"
                     (cons '"coordinate"
                           (cons '"provenance" (cons '"modality" '()))))))
        (if (and (equal? (poo-flow/src/ffi/temporal-policy#field
                          _%x2015%_
                          '"modality")
                         '"observed")
                 (exact-integer?
                  (poo-flow/src/ffi/temporal-policy#field
                   _%x2015%_
                   '"coordinate")))
            '#!void
            (let ()
              (declare (not safe))
              (error '"host policy requires observed integer instant")))
        (let ((__tmp4912
               (poo-flow/src/ffi/temporal-policy#field _%x2015%_ '"identity"))
              (__tmp4911
               (poo-flow/src/ffi/temporal-policy#field _%x2015%_ '"domain"))
              (__tmp4910
               (poo-flow/src/ffi/temporal-policy#field
                _%x2015%_
                '"coordinate"))
              (__tmp4909
               (poo-flow/src/ffi/temporal-policy#field
                _%x2015%_
                '"provenance")))
          (declare (not safe))
          (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-instant
           __tmp4912
           __tmp4911
           __tmp4910
           __tmp4909
           'observed))))
    (define poo-flow/src/ffi/temporal-policy#wire-instant
      (lambda (_%x2010%_)
        (let ((_%ht2012%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  '5
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (let ((__tmp4913
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%x2010%_ 'identity))))
            (declare (not safe))
            (__hash-put! _%ht2012%_ 'identity __tmp4913))
          (let ((__tmp4914
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%x2010%_ 'domain-identity))))
            (declare (not safe))
            (__hash-put! _%ht2012%_ 'domain __tmp4914))
          (let ((__tmp4915
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%x2010%_ 'coordinate))))
            (declare (not safe))
            (__hash-put! _%ht2012%_ 'coordinate __tmp4915))
          (let ((__tmp4916
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%x2010%_ 'provenance-identity))))
            (declare (not safe))
            (__hash-put! _%ht2012%_ 'provenance __tmp4916))
          (let ((__tmp4917
                 (symbol->string
                  (let ()
                    (declare (not safe))
                    (clan/poo/object#.ref _%x2010%_ 'modality)))))
            (declare (not safe))
            (__hash-put! _%ht2012%_ 'modality __tmp4917))
          _%ht2012%_)))
    (define poo-flow/src/ffi/temporal-policy#temporal-policy-refresh
      (lambda (_%x1998%_)
        (poo-flow/src/ffi/temporal-policy#fields
         _%x1998%_
         (cons '"schema"
               (cons '"policy"
                     (cons '"generation" (cons '"effectiveAt" '())))))
        (if (equal? (poo-flow/src/ffi/temporal-policy#field
                     _%x1998%_
                     '"schema")
                    '"poo-flow.temporal-policy-refresh-request.v1")
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported host policy schema")))
        (let ((_%p2000%_
               (poo-flow/src/ffi/temporal-policy#field _%x1998%_ '"policy")))
          (poo-flow/src/ffi/temporal-policy#fields
           _%p2000%_
           (cons '"identity"
                 (cons '"revision" (cons '"start" (cons '"end" '())))))
          (let* ((_%policy-value2002%_
                  (let ((__tmp4921
                         (poo-flow/src/ffi/temporal-policy#field
                          _%p2000%_
                          '"identity"))
                        (__tmp4920
                         (poo-flow/src/ffi/temporal-policy#field
                          _%p2000%_
                          '"revision"))
                        (__tmp4919
                         (poo-flow/src/ffi/temporal-policy#instant
                          (poo-flow/src/ffi/temporal-policy#field
                           _%p2000%_
                           '"start")))
                        (__tmp4918
                         (poo-flow/src/ffi/temporal-policy#instant
                          (poo-flow/src/ffi/temporal-policy#field
                           _%p2000%_
                           '"end"))))
                    (declare (not safe))
                    (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-policy
                     __tmp4921
                     __tmp4920
                     __tmp4919
                     __tmp4918)))
                 (_%snapshot2004%_
                  (let ((__tmp4923
                         (poo-flow/src/ffi/temporal-policy#field
                          _%x1998%_
                          '"generation"))
                        (__tmp4922
                         (poo-flow/src/ffi/temporal-policy#instant
                          (poo-flow/src/ffi/temporal-policy#field
                           _%x1998%_
                           '"effectiveAt"))))
                    (declare (not safe))
                    (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-refresh!
                     poo-flow/src/ffi/temporal-policy#host
                     _%policy-value2002%_
                     __tmp4923
                     __tmp4922)))
                 (_%ht2007%_
                  (let ()
                    (declare (not safe))
                    (make-hash-table__%
                     '#f
                     '12
                     absent-value
                     absent-value
                     absent-value
                     absent-value
                     absent-value
                     absent-value
                     absent-value))))
            (let ()
              (declare (not safe))
              (__hash-put!
               _%ht2007%_
               'schema
               '"poo-flow.temporal-policy-refresh-result.v1"))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'abiVersion '1))
            (let ((__tmp4924
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref _%policy-value2002%_ 'identity))))
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'policyIdentity __tmp4924))
            (let ((__tmp4925
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref
                      _%policy-value2002%_
                      'semantic-digest))))
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'policyDigest __tmp4925))
            (let ((__tmp4926
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref _%snapshot2004%_ 'generation))))
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'generation __tmp4926))
            (let ((__tmp4927
                   (poo-flow/src/ffi/temporal-policy#wire-instant
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%snapshot2004%_ 'effective-at)))))
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'effectiveAt __tmp4927))
            (let ()
              (declare (not safe))
              (__hash-put!
               _%ht2007%_
               'trustBasis
               '"host-registered-policy-snapshot"))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'proofAdmitted '#f))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'sourceAuthenticated '#f))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'selectionAdmitted '#f))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2007%_ 'actionAuthorized '#f))
            (let () (declare (not safe)) (__hash-put! _%ht2007%_ 'durable '#f))
            _%ht2007%_))))
    (define poo-flow/src/ffi/temporal-policy#temporal-policy-guard-call
      (lambda (_%x1989%_)
        (poo-flow/src/ffi/temporal-policy#fields
         _%x1989%_
         (cons '"schema"
               (cons '"expectedGeneration"
                     (cons '"expectedPolicyDigest" (cons '"task" '())))))
        (if (equal? (poo-flow/src/ffi/temporal-policy#field
                     _%x1989%_
                     '"schema")
                    '"poo-flow.temporal-support-guard-request.v1")
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported host guard schema")))
        (let* ((_%inputs1991%_
                (let ((__tmp4928
                       (poo-flow/src/ffi/temporal-policy#field
                        _%x1989%_
                        '"task")))
                  (declare (not safe))
                  (poo-flow/src/ffi/temporal-support#temporal-support-input
                   __tmp4928)))
               (_%result1993%_
                (apply poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-guard
                       poo-flow/src/ffi/temporal-policy#host
                       (poo-flow/src/ffi/temporal-policy#field
                        _%x1989%_
                        '"expectedGeneration")
                       (poo-flow/src/ffi/temporal-policy#field
                        _%x1989%_
                        '"expectedPolicyDigest")
                       _%inputs1991%_))
               (_%ht1995%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '14
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ()
            (declare (not safe))
            (__hash-put!
             _%ht1995%_
             'schema
             '"poo-flow.temporal-support-guard-result.v1"))
          (let () (declare (not safe)) (__hash-put! _%ht1995%_ 'abiVersion '1))
          (let ((__tmp4929
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1993%_ 'semantic-digest))))
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'bindingDigest __tmp4929))
          (let ((__tmp4930
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1993%_ 'policy-digest))))
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'policyDigest __tmp4930))
          (let ((__tmp4931
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref
                    _%result1993%_
                    'expected-policy-digest))))
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'expectedPolicyDigest __tmp4931))
          (let ((__tmp4932
                 (symbol->string
                  (let ()
                    (declare (not safe))
                    (clan/poo/object#.ref _%result1993%_ 'policy-status)))))
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'policyStatus __tmp4932))
          (let ((__tmp4933
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1993%_ 'policy-applicable?))))
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'policyApplicable __tmp4933))
          (let ((__tmp4934
                 (poo-flow/src/ffi/temporal-policy#wire-instant
                  (let ()
                    (declare (not safe))
                    (clan/poo/object#.ref _%result1993%_ 'effective-at)))))
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'effectiveAt __tmp4934))
          (let ((__tmp4935
                 (let ((__tmp4936
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%result1993%_ 'evaluation))))
                   (declare (not safe))
                   (poo-flow/src/ffi/temporal-support#temporal-support-result
                    __tmp4936))))
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'evaluation __tmp4935))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'proofAdmitted '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'sourceAuthenticated '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'selectionAdmitted '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1995%_ 'actionAuthorized '#f))
          (let () (declare (not safe)) (__hash-put! _%ht1995%_ 'durable '#f))
          _%ht1995%_)))))
