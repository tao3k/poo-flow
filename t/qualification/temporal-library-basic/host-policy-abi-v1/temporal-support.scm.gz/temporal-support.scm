(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/src/ffi/temporal-support::timestamp 1791201758)
  (begin
    (define poo-flow/src/ffi/temporal-support#field
      (lambda (_%x2039%_ _%key2040%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2039%_ 'HashTable::t))
                 (let* ((_%h2042%_ _%x2039%_)
                        (_%k2045%_ _%key2040%_)
                        (_%h2049%_ _%h2042%_)
                        (_%h2051%_ _%h2049%_))
                   (declare (not safe))
                   (__hash-key? _%h2051%_ _%k2045%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"missing support field" _%key2040%_)))
        (let* ((_%h2063%_ _%x2039%_)
               (_%key2066%_ _%key2040%_)
               (_%default2069%_ absent-obj)
               (_%h2073%_
                (let ()
                  (declare (not safe))
                  (cast HashTable::interface _%h2063%_)))
               (_%h2075%_ _%h2073%_))
          (declare (not safe))
          (__hash-ref__% _%h2075%_ _%key2066%_ _%default2069%_))))
    (define poo-flow/src/ffi/temporal-support#fields
      (lambda (_%x2016%_ _%names2017%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2016%_ 'HashTable::t))
                 (= (let* ((_%h2019%_ _%x2016%_)
                           (_%h2023%_ _%h2019%_)
                           (_%h2025%_ _%h2023%_))
                      (declare (not safe))
                      (__hash-length _%h2025%_))
                    (length _%names2017%_)))
            '#!void
            (let () (declare (not safe)) (error '"unexpected support fields")))
        (for-each
         (lambda (_%key2037%_)
           (poo-flow/src/ffi/temporal-support#field _%x2016%_ _%key2037%_))
         _%names2017%_)))
    (define poo-flow/src/ffi/temporal-support#bounded-list
      (lambda (_%x2013%_ _%limit2014%_)
        (if (and (list? _%x2013%_)
                 (<= (let () (declare (not safe)) (##length _%x2013%_))
                     _%limit2014%_))
            '#!void
            (let () (declare (not safe)) (error '"support inventory bound")))
        _%x2013%_))
    (define poo-flow/src/ffi/temporal-support#instant
      (lambda (_%domain2010%_ _%position2011%_)
        (if (and (integer? _%position2011%_) (exact? _%position2011%_))
            '#!void
            (let () (declare (not safe)) (error '"support clock coordinate")))
        (let ((__tmp4908 (number->string _%position2011%_)))
          (declare (not safe))
          (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-instant
           __tmp4908
           _%domain2010%_
           _%position2011%_
           '"abi-caller"
           'observed))))
    (define poo-flow/src/ffi/temporal-support#temporal-support-input
      (lambda (_%x1969%_)
        (poo-flow/src/ffi/temporal-support#fields
         _%x1969%_
         (cons '"schema"
               (cons '"program"
                     (cons '"journal"
                           (cons '"asOf"
                                 (cons '"validAt" (cons '"budget" '())))))))
        (if (equal? (poo-flow/src/ffi/temporal-support#field
                     _%x1969%_
                     '"schema")
                    '"poo-flow.temporal-support-request.v1")
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported support schema")))
        (let* ((_%p1971%_
                (poo-flow/src/ffi/temporal-support#field _%x1969%_ '"program"))
               (_%j1973%_
                (poo-flow/src/ffi/temporal-support#field
                 _%x1969%_
                 '"journal")))
          (poo-flow/src/ffi/temporal-support#fields
           _%p1971%_
           (cons '"identity"
                 (cons '"policy" (cons '"complete" (cons '"supports" '())))))
          (poo-flow/src/ffi/temporal-support#fields
           _%j1973%_
           (cons '"identity"
                 (cons '"admissionDomain"
                       (cons '"validDomain" (cons '"revisions" '())))))
          (let* ((_%supports1980%_
                  (map (lambda (_%s1976%_)
                         (poo-flow/src/ffi/temporal-support#fields
                          _%s1976%_
                          (cons '"identity"
                                (cons '"conclusion"
                                      (cons '"proof"
                                            (cons '"premises"
                                                  (cons '"parents" '()))))))
                         (let ((__tmp4915
                                (poo-flow/src/ffi/temporal-support#field
                                 _%s1976%_
                                 '"identity"))
                               (__tmp4914
                                (poo-flow/src/ffi/temporal-support#field
                                 _%s1976%_
                                 '"conclusion"))
                               (__tmp4913
                                (poo-flow/src/ffi/temporal-support#field
                                 _%s1976%_
                                 '"proof"))
                               (__tmp4910
                                (map (lambda (_%v1978%_)
                                       (poo-flow/src/ffi/temporal-support#fields
                                        _%v1978%_
                                        (cons '"subject"
                                              (cons '"revision" '())))
                                       (let ((__tmp4912
                                              (poo-flow/src/ffi/temporal-support#field
                                               _%v1978%_
                                               '"subject"))
                                             (__tmp4911
                                              (poo-flow/src/ffi/temporal-support#field
                                               _%v1978%_
                                               '"revision")))
                                         (declare (not safe))
                                         (poo-flow/modules/temporal-causality/truth-maintenance/support/objects#poo-flow-temporal-support-premise
                                          __tmp4912
                                          __tmp4911)))
                                     (poo-flow/src/ffi/temporal-support#bounded-list
                                      (poo-flow/src/ffi/temporal-support#field
                                       _%s1976%_
                                       '"premises")
                                      '128)))
                               (__tmp4909
                                (poo-flow/src/ffi/temporal-support#bounded-list
                                 (poo-flow/src/ffi/temporal-support#field
                                  _%s1976%_
                                  '"parents")
                                 '128)))
                           (declare (not safe))
                           (poo-flow/modules/temporal-causality/truth-maintenance/support/objects#poo-flow-temporal-support
                            __tmp4915
                            __tmp4914
                            __tmp4913
                            __tmp4910
                            __tmp4909)))
                       (poo-flow/src/ffi/temporal-support#bounded-list
                        (poo-flow/src/ffi/temporal-support#field
                         _%p1971%_
                         '"supports")
                        '128)))
                 (_%program1982%_
                  (let ((__tmp4918
                         (poo-flow/src/ffi/temporal-support#field
                          _%p1971%_
                          '"identity"))
                        (__tmp4917
                         (poo-flow/src/ffi/temporal-support#field
                          _%p1971%_
                          '"policy"))
                        (__tmp4916
                         (poo-flow/src/ffi/temporal-support#field
                          _%p1971%_
                          '"complete")))
                    (declare (not safe))
                    (poo-flow/modules/temporal-causality/truth-maintenance/support/funs#poo-flow-temporal-support-program
                     __tmp4918
                     __tmp4917
                     __tmp4916
                     _%supports1980%_)))
                 (_%revisions1999%_
                  (map (lambda (_%r1984%_)
                         (poo-flow/src/ffi/temporal-support#fields
                          _%r1984%_
                          (cons '"identity"
                                (cons '"subject"
                                      (cons '"operation"
                                            (cons '"predecessor"
                                                  (cons '"admitted"
                                                        (cons '"validRange"
                                                              (cons '"content"
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                         (let* ((_%operation1986%_
                                 (poo-flow/src/ffi/temporal-support#field
                                  _%r1984%_
                                  '"operation"))
                                (_%op1992%_
                                 (if (equal? _%operation1986%_ '"assert")
                                     'assert
                                     (if (equal? _%operation1986%_ '"correct")
                                         'correct
                                         (if (equal? _%operation1986%_
                                                     '"retract")
                                             'retract
                                             (let ()
                                               (declare (not safe))
                                               (error '"invalid support revision operation"))))))
                                (_%range1994%_
                                 (poo-flow/src/ffi/temporal-support#field
                                  _%r1984%_
                                  '"validRange"))
                                (_%interval1996%_
                                 (if _%range1994%_
                                     (begin
                                       (if (and (list? _%range1994%_)
                                                (= (let ()
                                                     (declare (not safe))
                                                     (##length _%range1994%_))
                                                   '2))
                                           '#!void
                                           (let ()
                                             (declare (not safe))
                                             (error '"invalid support validity range")))
                                       (let ((__tmp4921
                                              (poo-flow/src/ffi/temporal-support#field
                                               _%r1984%_
                                               '"identity"))
                                             (__tmp4920
                                              (poo-flow/src/ffi/temporal-support#instant
                                               (poo-flow/src/ffi/temporal-support#field
                                                _%j1973%_
                                                '"validDomain")
                                               (car _%range1994%_)))
                                             (__tmp4919
                                              (poo-flow/src/ffi/temporal-support#instant
                                               (poo-flow/src/ffi/temporal-support#field
                                                _%j1973%_
                                                '"validDomain")
                                               (cadr _%range1994%_))))
                                         (declare (not safe))
                                         (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-interval
                                          __tmp4921
                                          __tmp4920
                                          __tmp4919
                                          '#t
                                          '#f)))
                                     '#f)))
                           (let ((__tmp4926
                                  (poo-flow/src/ffi/temporal-support#field
                                   _%r1984%_
                                   '"identity"))
                                 (__tmp4925
                                  (poo-flow/src/ffi/temporal-support#field
                                   _%r1984%_
                                   '"subject"))
                                 (__tmp4924
                                  (poo-flow/src/ffi/temporal-support#field
                                   _%r1984%_
                                   '"predecessor"))
                                 (__tmp4923
                                  (poo-flow/src/ffi/temporal-support#instant
                                   (poo-flow/src/ffi/temporal-support#field
                                    _%j1973%_
                                    '"admissionDomain")
                                   (poo-flow/src/ffi/temporal-support#field
                                    _%r1984%_
                                    '"admitted")))
                                 (__tmp4922
                                  (poo-flow/src/ffi/temporal-support#field
                                   _%r1984%_
                                   '"content")))
                             (declare (not safe))
                             (poo-flow/modules/temporal-causality/revisions/objects#poo-flow-temporal-evidence-revision
                              __tmp4926
                              __tmp4925
                              _%op1992%_
                              __tmp4924
                              __tmp4923
                              _%interval1996%_
                              __tmp4922))))
                       (poo-flow/src/ffi/temporal-support#bounded-list
                        (poo-flow/src/ffi/temporal-support#field
                         _%j1973%_
                         '"revisions")
                        '128)))
                 (_%journal2001%_
                  (let ((__tmp4928
                         (poo-flow/src/ffi/temporal-support#field
                          _%j1973%_
                          '"identity"))
                        (__tmp4927
                         (poo-flow/src/ffi/temporal-support#field
                          _%j1973%_
                          '"admissionDomain")))
                    (declare (not safe))
                    (poo-flow/modules/temporal-causality/revisions/funs#poo-flow-temporal-evidence-journal
                     __tmp4928
                     __tmp4927
                     _%revisions1999%_)))
                 (_%valid2003%_
                  (poo-flow/src/ffi/temporal-support#field
                   _%x1969%_
                   '"validAt"))
                 (_%as-of2005%_
                  (poo-flow/src/ffi/temporal-support#instant
                   (poo-flow/src/ffi/temporal-support#field
                    _%j1973%_
                    '"admissionDomain")
                   (poo-flow/src/ffi/temporal-support#field
                    _%x1969%_
                    '"asOf")))
                 (_%valid-at2007%_
                  (if _%valid2003%_
                      (poo-flow/src/ffi/temporal-support#instant
                       (poo-flow/src/ffi/temporal-support#field
                        _%j1973%_
                        '"validDomain")
                       _%valid2003%_)
                      '#f)))
            (list _%program1982%_
                  _%journal2001%_
                  _%as-of2005%_
                  _%valid-at2007%_
                  (poo-flow/src/ffi/temporal-support#field
                   _%x1969%_
                   '"budget"))))))
    (define poo-flow/src/ffi/temporal-support#temporal-support-call
      (lambda (_%x1967%_)
        (poo-flow/src/ffi/temporal-support#temporal-support-result
         (let ((__tmp4929
                (poo-flow/src/ffi/temporal-support#temporal-support-input
                 _%x1967%_)))
           (declare (not safe))
           (##apply poo-flow/modules/temporal-causality/truth-maintenance/support/funs#poo-flow-temporal-support-evaluate
                    __tmp4929)))))
    (define poo-flow/src/ffi/temporal-support#temporal-support-result
      (lambda (_%result1957%_)
        (let ((_%ht1959%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  '13
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (let ()
            (declare (not safe))
            (__hash-put!
             _%ht1959%_
             'schema
             '"poo-flow.temporal-support-result.v1"))
          (let () (declare (not safe)) (__hash-put! _%ht1959%_ 'abiVersion '1))
          (let ((__tmp4930
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'program-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'programDigest __tmp4930))
          (let ((__tmp4931
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'semantic-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'bindingDigest __tmp4931))
          (let ((__tmp4932
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'cut-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'cutDigest __tmp4932))
          (let ((__tmp4933
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'projection-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'projectionDigest __tmp4933))
          (let ((__tmp4934
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref
                    _%result1957%_
                    'evaluated-support-count))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'evaluatedSupports __tmp4934))
          (let ((__tmp4935
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'budget-exhausted?))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'budgetExhausted __tmp4935))
          (let ((__tmp4936
                 (map (lambda (_%r1962%_)
                        (let ((_%ht1964%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '3
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ((__tmp4937
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%r1962%_
                                    'identity))))
                            (declare (not safe))
                            (__hash-put! _%ht1964%_ 'identity __tmp4937))
                          (let ((__tmp4938
                                 (symbol->string
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%r1962%_
                                     'status)))))
                            (declare (not safe))
                            (__hash-put! _%ht1964%_ 'status __tmp4938))
                          (let ((__tmp4939
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%r1962%_
                                    'active-support-identities))))
                            (declare (not safe))
                            (__hash-put! _%ht1964%_ 'activeSupports __tmp4939))
                          _%ht1964%_))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%result1957%_ 'conclusions)))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'conclusions __tmp4936))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'proofAdmitted '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'sourceAuthenticated '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'actionAuthorized '#f))
          (let () (declare (not safe)) (__hash-put! _%ht1959%_ 'durable '#f))
          _%ht1959%_)))))
