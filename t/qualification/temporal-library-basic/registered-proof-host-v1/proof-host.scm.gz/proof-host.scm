(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/modules/temporal-causality/evaluator/proof-host::timestamp
    1791208725)
  (begin
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
      (let ((__tmp7893 (list)) (__tmp7892 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'proof-context
         __tmp7893
         '(admission arguments program journal)
         __tmp7892
         '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#make-proof-context
      (lambda _%$args5061%_
        (apply make-instance
               poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
               _%$args5061%_)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-admission
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'admission)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-arguments
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'arguments)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-program
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'program)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-journal
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'journal)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-admission-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'admission)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-arguments-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'arguments)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'program)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context-journal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'journal)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-admission
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'admission)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-arguments
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'arguments)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-program
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'program)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-journal
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'journal)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-admission-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'admission)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-arguments-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'arguments)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'program)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-context-journal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
         'journal)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
      (let ((__tmp7895 (list)) (__tmp7894 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'proof-host-state
         __tmp7895
         '(policy-host current proofs)
         __tmp7894
         '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#make-proof-host-state
      (lambda _%$args5058%_
        (apply make-instance
               poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
               _%$args5058%_)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state-policy-host
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'policy-host)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state-current
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state-proofs
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'proofs)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state-policy-host-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'policy-host)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state-current-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state-proofs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'proofs)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-host-state-policy-host
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'policy-host)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-host-state-current
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-host-state-proofs
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'proofs)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-host-state-policy-host-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'policy-host)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-host-state-current-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#&proof-host-state-proofs-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
         'proofs)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#text?
      (lambda (_%x5056%_)
        (if (string? _%x5056%_)
            (< '0
               (let () (declare (not safe)) (##string-length _%x5056%_))
               '257)
            '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#tag?
      (lambda (_%x5053%_ _%k5054%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%x5053%_ 'clan/poo/object#object::t))
            (if (let ()
                  (declare (not safe))
                  (clan/poo/object#.slot? _%x5053%_ 'kind))
                (eq? (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%x5053%_ 'kind))
                     _%k5054%_)
                '#f)
            '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#digest
      (lambda (_%x4984%_)
        (let ((__tmp7896
               (let* ((_%bytes5004%_
                       (let* ((_%bytes4988%_
                               (let ((__tmp7897
                                      (call-with-output-string
                                       (lambda (_%p4986%_)
                                         (write _%x4984%_ _%p4986%_)))))
                                 (declare (not safe))
                                 (##string->utf8 __tmp7897)))
                              (_%bytes4993%_ _%bytes4988%_))
                         (declare (not safe))
                         (std/crypto/digest#__sha256 _%bytes4993%_)))
                      (_%start5007%_ '0)
                      (_%end5010%_
                       (let ()
                         (declare (not safe))
                         (##u8vector-length _%bytes5004%_)))
                      (_%bytes5015%_ _%bytes5004%_))
                 (if (and (let ()
                            (declare (not safe))
                            (##fx>= _%start5007%_ '0))
                          (let ((__tmp7898
                                 (let ((__tmp7899
                                        (let ()
                                          (declare (not safe))
                                          (##u8vector-length _%bytes5015%_))))
                                   (declare (not safe))
                                   (##fxmax __tmp7899 '1))))
                            (declare (not safe))
                            (##fx< _%start5007%_ __tmp7898)))
                     (let ((_%start5030%_ _%start5007%_))
                       (if (let ((__tmp7900
                                  (let ()
                                    (declare (not safe))
                                    (##u8vector-length _%bytes5015%_))))
                             (declare (not safe))
                             (##fx<= _%start5030%_ _%end5010%_ __tmp7900))
                           (let ((_%end5043%_ _%end5010%_))
                             (declare (not safe))
                             (std/encoding/hex#__hex-encode__%
                              _%bytes5015%_
                              _%start5030%_
                              _%end5043%_))
                           (begin
                             (raise-contract-violation-error
                              '"contract violation"
                              'context:
                              'poo-flow/modules/temporal-causality/evaluator/proof-host
                              'contract:
                              '(in-range-inclusive?
                                start
                                (u8vector-length bytes))
                              'value:
                              _%end5010%_)
                             '#!void)))
                     (begin
                       (raise-contract-violation-error
                        '"contract violation"
                        'context:
                        'poo-flow/modules/temporal-causality/evaluator/proof-host
                        'contract:
                        '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                        'value:
                        _%start5007%_)
                       '#!void)))))
          (declare (not safe))
          (##string-append '"sha256:" __tmp7896))))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-program
      (lambda (_%p4980%_)
        (let ((_%v4982%_
               (let ((__tmp7906
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p4980%_ 'identity)))
                     (__tmp7905
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p4980%_ 'catalog-digest)))
                     (__tmp7904
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p4980%_ 'generation)))
                     (__tmp7903
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p4980%_ 'ascent-generation)))
                     (__tmp7902
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p4980%_ 'relations)))
                     (__tmp7901
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p4980%_ 'rules))))
                 (declare (not safe))
                 (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-program
                  __tmp7906
                  __tmp7905
                  __tmp7904
                  __tmp7903
                  __tmp7902
                  __tmp7901))))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%v4982%_ 'semantic-digest))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p4980%_ 'semantic-digest)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"forged proof host catalog")))
          _%v4982%_)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-journal
      (lambda (_%j4976%_)
        (if (<= (length (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%j4976%_ 'revisions)))
                '128)
            '#!void
            (let ()
              (declare (not safe))
              (error '"proof host journal capacity exceeded")))
        (let ((_%v4978%_
               (let ((__tmp7909
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%j4976%_ 'identity)))
                     (__tmp7908
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%j4976%_
                         'admission-domain-identity)))
                     (__tmp7907
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%j4976%_ 'revisions))))
                 (declare (not safe))
                 (poo-flow/modules/temporal-causality/revisions/funs#poo-flow-temporal-evidence-journal
                  __tmp7909
                  __tmp7908
                  __tmp7907))))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%v4978%_ 'semantic-digest))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%j4976%_ 'semantic-digest)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"forged proof host journal")))
          _%v4978%_)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#poo-flow-temporal-derivation-context
      (lambda (_%held4920%_
               _%program4921%_
               _%correspondence4922%_
               _%bound4923%_
               _%admission4924%_
               _%snapshot4925%_
               _%candidate4926%_
               _%receipt4927%_
               _%steps4928%_
               _%max-nodes4929%_
               _%node-bindings4930%_
               _%output4931%_
               _%source-bindings4932%_
               _%journal4933%_)
        (let* ((_%arguments-value4935%_
                (list _%program4921%_
                      _%correspondence4922%_
                      _%bound4923%_
                      _%admission4924%_
                      _%snapshot4925%_
                      _%candidate4926%_
                      _%receipt4927%_
                      _%steps4928%_
                      _%max-nodes4929%_
                      _%node-bindings4930%_
                      _%output4931%_
                      _%source-bindings4932%_
                      _%journal4933%_))
               (_%verified-value4937%_
                (let ((__tmp7910 (cons _%held4920%_ _%arguments-value4935%_)))
                  (declare (not safe))
                  (##apply poo-flow/modules/temporal-causality/evaluator/derivation#poo-flow-temporal-mrr-derivation-admission-replay
                           __tmp7910)))
               (_%private-value4939%_
                (let ((__tmp7912
                       (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-program
                        _%program4921%_))
                      (__tmp7911
                       (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-journal
                        _%journal4933%_)))
                  (declare (not safe))
                  (##structure
                   poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                   _%verified-value4937%_
                   _%arguments-value4935%_
                   __tmp7912
                   __tmp7911)))
               (__obj7887
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
          (let ((__tmp7914
                 (list (cons 'kind
                             (let ((__tmp7915
                                    (lambda (_%self4959%_)
                                      'temporal.derivation-context.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp7915)))
                       (cons 'semantic-digest
                             (let ((__tmp7916
                                    (lambda (_%self4966%_)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%verified-value4937%_
                                         'semantic-digest)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp7916)))
                       (cons 'private-context
                             (let ((__tmp7917
                                    (lambda (_%self4971%_)
                                      _%private-value4939%_)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp7917)))))
                (__tmp7913 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp7914
             __tmp7913
             __obj7887))
          __obj7887)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#context
      (lambda (_%value4913%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/proof-host#tag?
                  _%value4913%_
                  'temporal.derivation-context.v1)
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot? _%value4913%_ 'private-context))
                 (let ((__tmp7918
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%value4913%_
                           'private-context))))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp7918
                    'poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid retained proof context")))
        (let* ((_%c4915%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%value4913%_ 'private-context)))
               (_%verified4917%_
                (let ((__tmp7919
                       (cons (##structure-ref
                              _%c4915%_
                              '1
                              poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                              '#f)
                             (##structure-ref
                              _%c4915%_
                              '2
                              poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                              '#f))))
                  (declare (not safe))
                  (##apply poo-flow/modules/temporal-causality/evaluator/derivation#poo-flow-temporal-mrr-derivation-admission-replay
                           __tmp7919))))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%value4913%_ 'semantic-digest))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%verified4917%_
                         'semantic-digest)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"retained proof context digest mismatch")))
          _%c4915%_)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#poo-flow-temporal-proof-host
      (lambda (_%policy-host-value4887%_)
        (let ((__obj7888
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp7921
                 (list (cons 'kind
                             (let ((__tmp7922
                                    (lambda (_%self4901%_)
                                      'temporal.proof-host.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp7922)))
                       (cons 'private-runtime-state
                             (let ((__tmp7923
                                    (lambda (_%self4908%_)
                                      (let ((__tmp7925
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value)))
                                            (__tmp7924
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value))))
                                        (declare (not safe))
                                        (##structure
                                         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
                                         _%policy-host-value4887%_
                                         __tmp7925
                                         __tmp7924)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp7923)))))
                (__tmp7920 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp7921
             __tmp7920
             __obj7888))
          __obj7888)))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#state
      (lambda (_%host4885%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/proof-host#tag?
                  _%host4885%_
                  'temporal.proof-host.v1)
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot?
                    _%host4885%_
                    'private-runtime-state))
                 (let ((__tmp7926
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%host4885%_
                           'private-runtime-state))))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp7926
                    'poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid proof host capability")))
        (let ()
          (declare (not safe))
          (clan/poo/object#.ref _%host4885%_ 'private-runtime-state))))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#poo-flow-temporal-proof-host-refresh!
      (lambda (_%host4710%_
               _%identity-value4711%_
               _%generation-value4712%_
               _%program4713%_
               _%journal4714%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/proof-host#text?
                  _%identity-value4711%_)
                 (exact-integer? _%generation-value4712%_)
                 (<= '0 _%generation-value4712%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid proof host state identity or generation")))
        (let* ((_%s4716%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#state
                 _%host4710%_))
               (_%p4718%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-program
                 _%program4713%_))
               (_%j4720%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-journal
                 _%journal4714%_))
               (_%current4722%_
                (##structure-ref
                 _%s4716%_
                 '2
                 poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
                 '#f))
               (_%old4749%_
                (let* ((_%h4724%_ _%current4722%_)
                       (_%key4727%_ _%identity-value4711%_)
                       (_%h4731%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h4724%_)))
                       (_%h4733%_ _%h4731%_))
                  (declare (not safe))
                  (__hash-get _%h4733%_ _%key4727%_)))
               (_%fingerprint-value4751%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#digest
                 (list 'temporal.proof-host-snapshot.v1
                       _%identity-value4711%_
                       _%generation-value4712%_
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref _%p4718%_ 'semantic-digest))
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref _%j4720%_ 'semantic-digest))))))
          (if _%old4749%_
              (begin
                (if (or (> _%generation-value4712%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%old4749%_ 'generation)))
                        (and (= _%generation-value4712%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%old4749%_
                                   'generation)))
                             (equal? _%fingerprint-value4751%_
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%old4749%_
                                        'semantic-digest)))))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"proof host generation rollback or conflict")))
                (let* ((_%old-j4757%_
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%old4749%_ 'journal)))
                       (_%ids4761%_
                        (map (lambda (_%r4759%_)
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref _%r4759%_ 'identity)))
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%old-j4757%_
                                'revisions))))
                       (_%retained4765%_
                        (filter (lambda (_%r4763%_)
                                  (let ((__tmp7927
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%r4763%_
                                            'identity))))
                                    (declare (not safe))
                                    (##member __tmp7927 _%ids4761%_)))
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%j4720%_
                                   'revisions))))
                       (_%prefix4767%_
                        (let ((__tmp7929
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref _%j4720%_ 'identity)))
                              (__tmp7928
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref
                                  _%j4720%_
                                  'admission-domain-identity))))
                          (declare (not safe))
                          (poo-flow/modules/temporal-causality/revisions/funs#poo-flow-temporal-evidence-journal
                           __tmp7929
                           __tmp7928
                           _%retained4765%_))))
                  (if (equal? (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%prefix4767%_
                                 'semantic-digest))
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%old-j4757%_
                                 'semantic-digest)))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"proof host cannot rewrite or remove evidence history")))))
              '#!void)
          (if (or _%old4749%_
                  (< (let* ((_%h4773%_ _%current4722%_)
                            (_%h4777%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h4773%_)))
                            (_%h4779%_ _%h4777%_))
                       (declare (not safe))
                       (__hash-length _%h4779%_))
                     '128))
              '#!void
              (let ()
                (declare (not safe))
                (error '"proof host state capacity exceeded")))
          (let ((_%value4858%_
                 (let ((__obj7889
                        (let ()
                          (declare (not safe))
                          (##structure
                           clan/poo/object#object::t
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp7931
                          (list (cons 'kind
                                      (let ((__tmp7932
                                             (lambda (_%self4811%_)
                                               'temporal.proof-host-snapshot.v1)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7932)))
                                (cons 'identity
                                      (let ((__tmp7933
                                             (lambda (_%self4818%_)
                                               (string-copy
                                                _%identity-value4711%_))))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7933)))
                                (cons 'generation
                                      (let ((__tmp7934
                                             (lambda (_%self4823%_)
                                               _%generation-value4712%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7934)))
                                (cons 'program
                                      (let ((__tmp7935
                                             (lambda (_%self4828%_)
                                               _%p4718%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7935)))
                                (cons 'journal
                                      (let ((__tmp7936
                                             (lambda (_%self4833%_)
                                               _%j4720%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7936)))
                                (cons 'semantic-digest
                                      (let ((__tmp7937
                                             (lambda (_%self4838%_)
                                               _%fingerprint-value4751%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7937)))
                                (cons 'source-authenticated?
                                      (let ((__tmp7938
                                             (lambda (_%self4843%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7938)))
                                (cons 'action-authorized?
                                      (let ((__tmp7939
                                             (lambda (_%self4848%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7939)))
                                (cons 'durable?
                                      (let ((__tmp7940
                                             (lambda (_%self4853%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp7940)))))
                         (__tmp7930 (list)))
                     (declare (not safe))
                     (clan/poo/object#object:::init!__%
                      '#f
                      '()
                      __tmp7931
                      __tmp7930
                      __obj7889))
                   __obj7889)))
            (let* ((_%h4860%_ _%current4722%_)
                   (_%key4863%_ (string-copy _%identity-value4711%_))
                   (_%value4866%_ _%value4858%_)
                   (_%h4870%_
                    (let ()
                      (declare (not safe))
                      (cast HashTable::interface _%h4860%_)))
                   (_%h4872%_ _%h4870%_))
              (declare (not safe))
              (__hash-put! _%h4872%_ _%key4863%_ _%value4866%_))
            _%value4858%_))))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#poo-flow-temporal-proof-host-register!
      (lambda (_%host4511%_
               _%identity-value4512%_
               _%expected-state-digest4513%_
               _%context-value4514%_
               _%policy-identity-value4515%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/proof-host#text?
                  _%identity-value4512%_)
                 (poo-flow/modules/temporal-causality/evaluator/proof-host#text?
                  _%expected-state-digest4513%_)
                 (poo-flow/modules/temporal-causality/evaluator/proof-host#text?
                  _%policy-identity-value4515%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid proof host registration")))
        (let* ((_%s4517%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#state
                 _%host4511%_))
               (_%current4541%_
                (let* ((_%h4519%_
                        (##structure-ref
                         _%s4517%_
                         '2
                         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
                         '#f))
                       (_%key4522%_ _%identity-value4512%_)
                       (_%h4526%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h4519%_)))
                       (_%h4528%_ _%h4526%_))
                  (declare (not safe))
                  (__hash-get _%h4528%_ _%key4522%_)))
               (_%c4543%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#context
                 _%context-value4514%_))
               (_%a4545%_
                (##structure-ref
                 _%c4543%_
                 '1
                 poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                 '#f))
               (_%proof-digest-value4547%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%a4545%_ 'semantic-digest)))
               (_%key-value4549%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#digest
                 (list 'temporal.proof-host-registration.v1
                       _%identity-value4512%_
                       _%expected-state-digest4513%_
                       _%proof-digest-value4547%_
                       _%policy-identity-value4515%_)))
               (_%proofs4551%_
                (##structure-ref
                 _%s4517%_
                 '3
                 poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
                 '#f)))
          (if (and _%current4541%_
                   (equal? _%expected-state-digest4513%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%current4541%_
                              'semantic-digest)))
                   (equal? (let ((__tmp7941
                                  (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-program
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%current4541%_
                                      'program)))))
                             (declare (not safe))
                             (clan/poo/object#.ref __tmp7941 'semantic-digest))
                           (let ((__tmp7942
                                  (##structure-ref
                                   _%c4543%_
                                   '3
                                   poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                                   '#f)))
                             (declare (not safe))
                             (clan/poo/object#.ref
                              __tmp7942
                              'semantic-digest)))
                   (equal? (let ((__tmp7943
                                  (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-journal
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%current4541%_
                                      'journal)))))
                             (declare (not safe))
                             (clan/poo/object#.ref __tmp7943 'semantic-digest))
                           (let ((__tmp7944
                                  (##structure-ref
                                   _%c4543%_
                                   '4
                                   poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                                   '#f)))
                             (declare (not safe))
                             (clan/poo/object#.ref
                              __tmp7944
                              'semantic-digest))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"unregistered or stale proof host state")))
          (if (or (let* ((_%h4554%_ _%proofs4551%_)
                         (_%k4557%_ _%key-value4549%_)
                         (_%h4561%_
                          (let ()
                            (declare (not safe))
                            (cast HashTable::interface _%h4554%_)))
                         (_%h4563%_ _%h4561%_))
                    (declare (not safe))
                    (__hash-key? _%h4563%_ _%k4557%_))
                  (< (let* ((_%h4584%_ _%proofs4551%_)
                            (_%h4588%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h4584%_)))
                            (_%h4590%_ _%h4588%_))
                       (declare (not safe))
                       (__hash-length _%h4590%_))
                     '128))
              '#!void
              (let ()
                (declare (not safe))
                (error '"proof host admission capacity exceeded")))
          (if (let* ((_%h4601%_ _%proofs4551%_)
                     (_%k4604%_ _%key-value4549%_)
                     (_%h4608%_
                      (let ()
                        (declare (not safe))
                        (cast HashTable::interface _%h4601%_)))
                     (_%h4610%_ _%h4608%_))
                (declare (not safe))
                (__hash-key? _%h4610%_ _%k4604%_))
              '#!void
              (let* ((_%h4621%_ _%proofs4551%_)
                     (_%key4624%_ _%key-value4549%_)
                     (_%value4627%_
                      (list (string-copy _%identity-value4512%_)
                            _%context-value4514%_
                            (string-copy _%policy-identity-value4515%_)
                            (string-copy _%expected-state-digest4513%_)))
                     (_%h4631%_
                      (let ()
                        (declare (not safe))
                        (cast HashTable::interface _%h4621%_)))
                     (_%h4633%_ _%h4631%_))
                (declare (not safe))
                (__hash-put! _%h4633%_ _%key4624%_ _%value4627%_)))
          (let ((__obj7890
                 (let ()
                   (declare (not safe))
                   (##structure
                    clan/poo/object#object::t
                    '#f
                    '#f
                    '#f
                    '#f
                    '#f
                    '#f
                    '#f))))
            (let ((__tmp7946
                   (list (cons 'kind
                               (let ((__tmp7947
                                      (lambda (_%self4663%_)
                                        'temporal.proof-host-registration.v1)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7947)))
                         (cons 'identity
                               (let ((__tmp7948
                                      (lambda (_%self4670%_)
                                        _%key-value4549%_)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7948)))
                         (cons 'proof-digest
                               (let ((__tmp7949
                                      (lambda (_%self4675%_)
                                        _%proof-digest-value4547%_)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7949)))
                         (cons 'original-state-digest
                               (let ((__tmp7950
                                      (lambda (_%self4680%_)
                                        _%expected-state-digest4513%_)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7950)))
                         (cons 'proof-admitted?
                               (let ((__tmp7951 (lambda (_%self4685%_) '#t)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7951)))
                         (cons 'source-authenticated?
                               (let ((__tmp7952 (lambda (_%self4690%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7952)))
                         (cons 'selection-admitted?
                               (let ((__tmp7953 (lambda (_%self4695%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7953)))
                         (cons 'action-authorized?
                               (let ((__tmp7954 (lambda (_%self4700%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7954)))
                         (cons 'durable?
                               (let ((__tmp7955 (lambda (_%self4705%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp7955)))))
                  (__tmp7945 (list)))
              (declare (not safe))
              (clan/poo/object#object:::init!__%
               '#f
               '()
               __tmp7946
               __tmp7945
               __obj7890))
            __obj7890))))
    (define poo-flow/modules/temporal-causality/evaluator/proof-host#poo-flow-temporal-proof-host-current
      (lambda (_%host4310%_
               _%registration-value4311%_
               _%expected-state-generation4312%_
               _%expected-policy-generation4313%_
               _%expected-policy-digest4314%_
               _%budget4315%_)
        (let* ((_%s4317%_
                (poo-flow/modules/temporal-causality/evaluator/proof-host#state
                 _%host4310%_))
               (_%held4341%_
                (let* ((_%h4319%_
                        (##structure-ref
                         _%s4317%_
                         '3
                         poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
                         '#f))
                       (_%key4322%_ _%registration-value4311%_)
                       (_%h4326%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h4319%_)))
                       (_%h4328%_ _%h4326%_))
                  (declare (not safe))
                  (__hash-get _%h4328%_ _%key4322%_))))
          (if _%held4341%_
              '#!void
              (let ()
                (declare (not safe))
                (error '"unknown registered proof")))
          (let* ((_%c4344%_
                  (poo-flow/modules/temporal-causality/evaluator/proof-host#context
                   (cadr _%held4341%_)))
                 (_%a4346%_
                  (##structure-ref
                   _%c4344%_
                   '1
                   poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                   '#f))
                 (_%current4372%_
                  (let* ((_%h4348%_
                          (##structure-ref
                           _%s4317%_
                           '2
                           poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
                           '#f))
                         (_%key4351%_ (car _%held4341%_))
                         (_%h4355%_
                          (let ()
                            (declare (not safe))
                            (cast HashTable::interface _%h4348%_)))
                         (_%h4357%_ _%h4355%_))
                    (declare (not safe))
                    (__hash-get _%h4357%_ _%key4351%_))))
            (if (and _%current4372%_
                     (exact-integer? _%expected-state-generation4312%_)
                     (= _%expected-state-generation4312%_
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%current4372%_ 'generation))))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"unregistered or stale proof host generation")))
            (let* ((_%p4375%_
                    (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-program
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%current4372%_ 'program))))
                   (_%j4377%_
                    (poo-flow/modules/temporal-causality/evaluator/proof-host#canonical-journal
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%current4372%_ 'journal))))
                   (_%same-catalog-value4379%_
                    (equal? (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               _%p4375%_
                               'semantic-digest))
                            (let ((__tmp7956
                                   (##structure-ref
                                    _%c4344%_
                                    '3
                                    poo-flow/modules/temporal-causality/evaluator/proof-host#proof-context::t
                                    '#f)))
                              (declare (not safe))
                              (clan/poo/object#.ref
                               __tmp7956
                               'semantic-digest))))
                   (_%support-program-value4381%_
                    (let ((__tmp7958 (caddr _%held4341%_))
                          (__tmp7957
                           (list (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%a4346%_
                                    'support)))))
                      (declare (not safe))
                      (poo-flow/modules/temporal-causality/truth-maintenance/support/funs#poo-flow-temporal-support-program
                       _%registration-value4311%_
                       __tmp7958
                       '#t
                       __tmp7957)))
                   (_%guard-value4383%_
                    (let ((__tmp7959
                           (##structure-ref
                            _%s4317%_
                            '1
                            poo-flow/modules/temporal-causality/evaluator/proof-host#proof-host-state::t
                            '#f)))
                      (declare (not safe))
                      (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-guard-current
                       __tmp7959
                       _%expected-policy-generation4313%_
                       _%expected-policy-digest4314%_
                       _%support-program-value4381%_
                       _%j4377%_
                       _%budget4315%_)))
                   (_%support-status-value4385%_
                    (let ((__tmp7960
                           (car (let ((__tmp7961
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%guard-value4383%_
                                          'evaluation))))
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   __tmp7961
                                   'conclusions)))))
                      (declare (not safe))
                      (clan/poo/object#.ref __tmp7960 'status)))
                   (_%status-value4391%_
                    (if _%same-catalog-value4379%_
                        (if (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               _%guard-value4383%_
                               'policy-applicable?))
                            (if (eq? _%support-status-value4385%_ 'supported)
                                'current
                                _%support-status-value4385%_)
                            (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               _%guard-value4383%_
                               'policy-status)))
                        'stale-catalog))
                   (__obj7891
                    (let ()
                      (declare (not safe))
                      (##structure
                       clan/poo/object#object::t
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f
                       '#f))))
              (let ((__tmp7963
                     (list (cons 'kind
                                 (let ((__tmp7964
                                        (lambda (_%self4429%_)
                                          'temporal.proof-host-applicability.v1)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7964)))
                           (cons 'registration
                                 (let ((__tmp7965
                                        (lambda (_%self4436%_)
                                          _%registration-value4311%_)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7965)))
                           (cons 'proof-digest
                                 (let ((__tmp7966
                                        (lambda (_%self4441%_)
                                          (let ()
                                            (declare (not safe))
                                            (clan/poo/object#.ref
                                             _%a4346%_
                                             'semantic-digest)))))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7966)))
                           (cons 'original-state-digest
                                 (let ((__tmp7967
                                        (lambda (_%self4446%_)
                                          (cadddr _%held4341%_))))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7967)))
                           (cons 'current-state-digest
                                 (let ((__tmp7968
                                        (lambda (_%self4451%_)
                                          (let ()
                                            (declare (not safe))
                                            (clan/poo/object#.ref
                                             _%current4372%_
                                             'semantic-digest)))))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7968)))
                           (cons 'state-generation
                                 (let ((__tmp7969
                                        (lambda (_%self4456%_)
                                          _%expected-state-generation4312%_)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7969)))
                           (cons 'guard
                                 (let ((__tmp7970
                                        (lambda (_%self4461%_)
                                          _%guard-value4383%_)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7970)))
                           (cons 'status
                                 (let ((__tmp7971
                                        (lambda (_%self4466%_)
                                          _%status-value4391%_)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7971)))
                           (cons 'current?
                                 (let ((__tmp7972
                                        (lambda (_%self4471%_)
                                          (eq? _%status-value4391%_
                                               'current))))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7972)))
                           (cons 'semantic-digest
                                 (let ((__tmp7973
                                        (lambda (_%self4476%_)
                                          (poo-flow/modules/temporal-causality/evaluator/proof-host#digest
                                           (list 'temporal.proof-host-applicability.v1
                                                 _%registration-value4311%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%a4346%_
                                                    'semantic-digest))
                                                 (cadddr _%held4341%_)
                                                 (let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%current4372%_
                                                    'semantic-digest))
                                                 _%expected-state-generation4312%_
                                                 _%expected-policy-generation4313%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%guard-value4383%_
                                                    'semantic-digest))
                                                 _%status-value4391%_)))))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7973)))
                           (cons 'proof-admitted?
                                 (let ((__tmp7974 (lambda (_%self4481%_) '#t)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7974)))
                           (cons 'trust-basis
                                 (let ((__tmp7975
                                        (lambda (_%self4486%_)
                                          'host-registered-source-relative-native-proof)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7975)))
                           (cons 'source-authenticated?
                                 (let ((__tmp7976 (lambda (_%self4491%_) '#f)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7976)))
                           (cons 'selection-admitted?
                                 (let ((__tmp7977 (lambda (_%self4496%_) '#f)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7977)))
                           (cons 'action-authorized?
                                 (let ((__tmp7978 (lambda (_%self4501%_) '#f)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7978)))
                           (cons 'durable?
                                 (let ((__tmp7979 (lambda (_%self4506%_) '#f)))
                                   (declare (not safe))
                                   (##structure
                                    clan/poo/object#$self-slot-spec::t
                                    __tmp7979)))))
                    (__tmp7962 (list)))
                (declare (not safe))
                (clan/poo/object#object:::init!__%
                 '#f
                 '()
                 __tmp7963
                 __tmp7962
                 __obj7891))
              __obj7891)))))))
