(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host::timestamp
    1791208693)
  (begin
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
      (let ((__tmp6288 (list)) (__tmp6287 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'policy-host-state
         __tmp6288
         '(current revisions)
         __tmp6287
         '#f)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#make-policy-host-state
      (lambda _%$args3460%_
        (apply make-instance
               poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
               _%$args3460%_)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-current
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-revisions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-current-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state-revisions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-current
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-revisions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-current-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'current)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#&policy-host-state-revisions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
         'revisions)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host
      (lambda ()
        (let ((__obj6285
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp6290
                 (list (cons 'kind
                             (let ((__tmp6291
                                    (lambda (_%self3448%_)
                                      'poo-flow.temporal-causality.policy-host.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp6291)))
                       (cons 'private-runtime-state
                             (let ((__tmp6292
                                    (lambda (_%self3455%_)
                                      (let ((__tmp6294
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value)))
                                            (__tmp6293
                                             (let ()
                                               (declare (not safe))
                                               (make-hash-table__%
                                                '#f
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value
                                                absent-value))))
                                        (declare (not safe))
                                        (##structure
                                         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                                         __tmp6294
                                         __tmp6293)))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp6292)))))
                (__tmp6289 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp6290
             __tmp6289
             __obj6285))
          __obj6285)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#state
      (lambda (_%host3433%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%host3433%_
                    'clan/poo/object#object::t))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot? _%host3433%_ 'kind))
                 (eq? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%host3433%_ 'kind))
                      'poo-flow.temporal-causality.policy-host.v1)
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot?
                    _%host3433%_
                    'private-runtime-state))
                 (let ((__tmp6295
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%host3433%_
                           'private-runtime-state))))
                   (declare (not safe))
                   (##structure-instance-of?
                    __tmp6295
                    'poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid policy host capability")))
        (let ()
          (declare (not safe))
          (clan/poo/object#.ref _%host3433%_ 'private-runtime-state))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#instant-row
      (lambda (_%x3429%_)
        (let ((__tmp6296
               (lambda (_%s3431%_)
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%x3429%_ _%s3431%_)))))
          (declare (not safe))
          (##map __tmp6296
                 '(identity
                   domain-identity
                   coordinate
                   provenance-identity
                   modality)))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#canonical-policy
      (lambda (_%p3425%_)
        (let ((_%canonical3427%_
               (let ((__tmp6300
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3425%_ 'identity)))
                     (__tmp6299
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3425%_ 'revision-identity)))
                     (__tmp6298
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3425%_ 'start)))
                     (__tmp6297
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3425%_ 'end))))
                 (declare (not safe))
                 (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-policy
                  __tmp6300
                  __tmp6299
                  __tmp6298
                  __tmp6297))))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%p3425%_ 'semantic-digest))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%canonical3427%_
                         'semantic-digest)))
              '#!void
              (let () (declare (not safe)) (error '"forged host policy")))
          _%canonical3427%_)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-refresh!
      (lambda (_%host3197%_
               _%policy3198%_
               _%generation-value3199%_
               _%effective-value3200%_)
        (if (and (exact-integer? _%generation-value3199%_)
                 (<= '0 _%generation-value3199%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid host policy generation")))
        (let* ((_%s3202%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#state
                 _%host3197%_))
               (_%owned3204%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#canonical-policy
                 _%policy3198%_))
               (_%time-value3206%_
                (let ((__tmp6305
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3200%_
                          'identity)))
                      (__tmp6304
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3200%_
                          'domain-identity)))
                      (__tmp6303
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3200%_
                          'coordinate)))
                      (__tmp6302
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3200%_
                          'provenance-identity)))
                      (__tmp6301
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%effective-value3200%_
                          'modality))))
                  (declare (not safe))
                  (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-instant
                   __tmp6305
                   __tmp6304
                   __tmp6303
                   __tmp6302
                   __tmp6301)))
               (_%id3208%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%owned3204%_ 'identity)))
               (_%current3210%_
                (##structure-ref
                 _%s3202%_
                 '1
                 poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                 '#f))
               (_%history3212%_
                (##structure-ref
                 _%s3202%_
                 '2
                 poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                 '#f))
               (_%old3241%_
                (let* ((_%h3214%_ _%current3210%_)
                       (_%key3217%_ _%id3208%_)
                       (_%h3221%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h3214%_)))
                       (_%h3223%_ _%h3221%_))
                  (declare (not safe))
                  (__hash-get _%h3223%_ _%key3217%_)))
               (_%revision-key3243%_
                (list _%id3208%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%owned3204%_
                         'revision-identity))))
               (_%original3267%_
                (let* ((_%h3245%_ _%history3212%_)
                       (_%key3248%_ _%revision-key3243%_)
                       (_%h3252%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h3245%_)))
                       (_%h3254%_ _%h3252%_))
                  (declare (not safe))
                  (__hash-get _%h3254%_ _%key3248%_))))
          (if (and (eq? (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%time-value3206%_ 'modality))
                        'observed)
                   (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%time-value3206%_
                              'domain-identity))
                           (let ((__tmp6306
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%owned3204%_
                                     'start))))
                             (declare (not safe))
                             (clan/poo/object#.ref
                              __tmp6306
                              'domain-identity))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"host policy clock domain or modality mismatch")))
          (if _%original3267%_
              (if (equal? (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%original3267%_
                             'semantic-digest))
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%owned3204%_
                             'semantic-digest)))
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"host policy revision identity is immutable")))
              '#!void)
          (if _%old3241%_
              (begin
                (if (and (equal? (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%time-value3206%_
                                    'domain-identity))
                                 (let ((__tmp6307
                                        (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%old3241%_
                                           'effective-at))))
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    __tmp6307
                                    'domain-identity)))
                         (>= (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%time-value3206%_
                                'coordinate))
                             (let ((__tmp6308
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%old3241%_
                                       'effective-at))))
                               (declare (not safe))
                               (clan/poo/object#.ref __tmp6308 'coordinate))))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"host policy clock rollback")))
                (if (or (> _%generation-value3199%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%old3241%_ 'generation)))
                        (and (= _%generation-value3199%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%old3241%_
                                   'generation)))
                             (equal? (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%owned3204%_
                                        'semantic-digest))
                                     (let ((__tmp6309
                                            (let ()
                                              (declare (not safe))
                                              (clan/poo/object#.ref
                                               _%old3241%_
                                               'policy))))
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        __tmp6309
                                        'semantic-digest)))
                             (equal? (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#instant-row
                                      _%time-value3206%_)
                                     (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#instant-row
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%old3241%_
                                         'effective-at))))))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"host policy generation rollback or conflict"))))
              '#!void)
          (if (and (or _%old3241%_
                       (< (let* ((_%h3276%_ _%current3210%_)
                                 (_%h3280%_
                                  (let ()
                                    (declare (not safe))
                                    (cast HashTable::interface _%h3276%_)))
                                 (_%h3282%_ _%h3280%_))
                            (declare (not safe))
                            (__hash-length _%h3282%_))
                          '128))
                   (or _%original3267%_
                       (< (let* ((_%h3298%_ _%history3212%_)
                                 (_%h3302%_
                                  (let ()
                                    (declare (not safe))
                                    (cast HashTable::interface _%h3298%_)))
                                 (_%h3304%_ _%h3302%_))
                            (declare (not safe))
                            (__hash-length _%h3304%_))
                          '128)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"host policy registry capacity exceeded")))
          (let ((_%snapshot3374%_
                 (let ((__obj6286
                        (let ()
                          (declare (not safe))
                          (##structure
                           clan/poo/object#object::t
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp6311
                          (list (cons 'kind
                                      (let ((__tmp6312
                                             (lambda (_%self3332%_)
                                               'poo-flow.temporal-causality.policy-host-snapshot.v1)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6312)))
                                (cons 'policy
                                      (let ((__tmp6313
                                             (lambda (_%self3339%_)
                                               _%owned3204%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6313)))
                                (cons 'generation
                                      (let ((__tmp6314
                                             (lambda (_%self3344%_)
                                               _%generation-value3199%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6314)))
                                (cons 'effective-at
                                      (let ((__tmp6315
                                             (lambda (_%self3349%_)
                                               _%time-value3206%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6315)))
                                (cons 'trust-basis
                                      (let ((__tmp6316
                                             (lambda (_%self3354%_)
                                               'host-registered-policy-snapshot)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6316)))
                                (cons 'source-authenticated?
                                      (let ((__tmp6317
                                             (lambda (_%self3359%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6317)))
                                (cons 'action-authorized?
                                      (let ((__tmp6318
                                             (lambda (_%self3364%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6318)))
                                (cons 'durable?
                                      (let ((__tmp6319
                                             (lambda (_%self3369%_) '#f)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp6319)))))
                         (__tmp6310 (list)))
                     (declare (not safe))
                     (clan/poo/object#object:::init!__%
                      '#f
                      '()
                      __tmp6311
                      __tmp6310
                      __obj6286))
                   __obj6286)))
            (let* ((_%h3376%_ _%history3212%_)
                   (_%key3379%_ _%revision-key3243%_)
                   (_%value3382%_ _%owned3204%_)
                   (_%h3386%_
                    (let ()
                      (declare (not safe))
                      (cast HashTable::interface _%h3376%_)))
                   (_%h3388%_ _%h3386%_))
              (declare (not safe))
              (__hash-put! _%h3388%_ _%key3379%_ _%value3382%_))
            (let* ((_%h3401%_ _%current3210%_)
                   (_%key3404%_ _%id3208%_)
                   (_%value3407%_ _%snapshot3374%_)
                   (_%h3411%_
                    (let ()
                      (declare (not safe))
                      (cast HashTable::interface _%h3401%_)))
                   (_%h3413%_ _%h3411%_))
              (declare (not safe))
              (__hash-put! _%h3413%_ _%key3404%_ _%value3407%_))
            _%snapshot3374%_))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-guard
      (lambda (_%host3161%_
               _%expected-generation3162%_
               _%expected-policy-digest3163%_
               _%program3164%_
               _%journal3165%_
               _%as-of3166%_
               _%valid-at3167%_
               _%budget3168%_)
        (let* ((_%s3170%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#state
                 _%host3161%_))
               (_%snapshot3194%_
                (let* ((_%h3172%_
                        (##structure-ref
                         _%s3170%_
                         '1
                         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                         '#f))
                       (_%key3175%_
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%program3164%_
                           'policy-identity)))
                       (_%h3179%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h3172%_)))
                       (_%h3181%_ _%h3179%_))
                  (declare (not safe))
                  (__hash-get _%h3181%_ _%key3175%_))))
          (if (and _%snapshot3194%_
                   (exact-integer? _%expected-generation3162%_)
                   (= _%expected-generation3162%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%snapshot3194%_ 'generation))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"unregistered or stale host policy generation")))
          (let ((__tmp6321
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3194%_ 'policy)))
                (__tmp6320
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3194%_ 'effective-at))))
            (declare (not safe))
            (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-guard
             _%program3164%_
             _%journal3165%_
             _%as-of3166%_
             _%valid-at3167%_
             _%budget3168%_
             __tmp6321
             _%expected-policy-digest3163%_
             __tmp6320)))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#poo-flow-temporal-support-policy-host-guard-current
      (lambda (_%host3127%_
               _%expected-generation3128%_
               _%expected-policy-digest3129%_
               _%program3130%_
               _%journal3131%_
               _%budget3132%_)
        (let* ((_%s3134%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#state
                 _%host3127%_))
               (_%snapshot3158%_
                (let* ((_%h3136%_
                        (##structure-ref
                         _%s3134%_
                         '1
                         poo-flow/modules/temporal-causality/truth-maintenance/support/policy-host#policy-host-state::t
                         '#f))
                       (_%key3139%_
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref
                           _%program3130%_
                           'policy-identity)))
                       (_%h3143%_
                        (let ()
                          (declare (not safe))
                          (cast HashTable::interface _%h3136%_)))
                       (_%h3145%_ _%h3143%_))
                  (declare (not safe))
                  (__hash-get _%h3145%_ _%key3139%_))))
          (if (and _%snapshot3158%_
                   (exact-integer? _%expected-generation3128%_)
                   (= _%expected-generation3128%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%snapshot3158%_ 'generation))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"unregistered or stale host policy generation")))
          (let ((__tmp6325
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3158%_ 'effective-at)))
                (__tmp6324
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3158%_ 'effective-at)))
                (__tmp6323
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3158%_ 'policy)))
                (__tmp6322
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%snapshot3158%_ 'effective-at))))
            (declare (not safe))
            (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-guard
             _%program3130%_
             _%journal3131%_
             __tmp6325
             __tmp6324
             _%budget3132%_
             __tmp6323
             _%expected-policy-digest3129%_
             __tmp6322)))))))
