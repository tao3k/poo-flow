(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy::timestamp
    1791187423)
  (begin
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#text?
      (lambda (_%x3124%_)
        (if (string? _%x3124%_)
            (< '0
               (let () (declare (not safe)) (##string-length _%x3124%_))
               '257)
            '#f)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#digest
      (lambda (_%x3055%_)
        (let ((__tmp5949
               (let* ((_%bytes3075%_
                       (let* ((_%bytes3059%_
                               (let ((__tmp5950
                                      (call-with-output-string
                                       (lambda (_%p3057%_)
                                         (write _%x3055%_ _%p3057%_)))))
                                 (declare (not safe))
                                 (##string->utf8 __tmp5950)))
                              (_%bytes3064%_ _%bytes3059%_))
                         (declare (not safe))
                         (std/crypto/digest#__sha256 _%bytes3064%_)))
                      (_%start3078%_ '0)
                      (_%end3081%_
                       (let ()
                         (declare (not safe))
                         (##u8vector-length _%bytes3075%_)))
                      (_%bytes3086%_ _%bytes3075%_))
                 (if (and (let ()
                            (declare (not safe))
                            (##fx>= _%start3078%_ '0))
                          (let ((__tmp5951
                                 (let ((__tmp5952
                                        (let ()
                                          (declare (not safe))
                                          (##u8vector-length _%bytes3086%_))))
                                   (declare (not safe))
                                   (##fxmax __tmp5952 '1))))
                            (declare (not safe))
                            (##fx< _%start3078%_ __tmp5951)))
                     (let ((_%start3101%_ _%start3078%_))
                       (if (let ((__tmp5953
                                  (let ()
                                    (declare (not safe))
                                    (##u8vector-length _%bytes3086%_))))
                             (declare (not safe))
                             (##fx<= _%start3101%_ _%end3081%_ __tmp5953))
                           (let ((_%end3114%_ _%end3081%_))
                             (declare (not safe))
                             (std/encoding/hex#__hex-encode__%
                              _%bytes3086%_
                              _%start3101%_
                              _%end3114%_))
                           (begin
                             (raise-contract-violation-error
                              '"contract violation"
                              'context:
                              'poo-flow/modules/temporal-causality/truth-maintenance/support/policy
                              'contract:
                              '(in-range-inclusive?
                                start
                                (u8vector-length bytes))
                              'value:
                              _%end3081%_)
                             '#!void)))
                     (begin
                       (raise-contract-violation-error
                        '"contract violation"
                        'context:
                        'poo-flow/modules/temporal-causality/truth-maintenance/support/policy
                        'contract:
                        '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                        'value:
                        _%start3078%_)
                       '#!void)))))
          (declare (not safe))
          (##string-append '"sha256:" __tmp5949))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant
      (lambda (_%x3051%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%x3051%_
                    'clan/poo/object#object::t))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot? _%x3051%_ 'kind))
                 (eq? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%x3051%_ 'kind))
                      'poo-flow.temporal-causality.instant))
            '#!void
            (let () (declare (not safe)) (error '"invalid policy instant")))
        (let ((_%value3053%_
               (let ((__tmp5958
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%x3051%_ 'identity)))
                     (__tmp5957
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%x3051%_ 'domain-identity)))
                     (__tmp5956
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%x3051%_ 'coordinate)))
                     (__tmp5955
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%x3051%_ 'provenance-identity)))
                     (__tmp5954
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%x3051%_ 'modality))))
                 (declare (not safe))
                 (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-instant
                  __tmp5958
                  __tmp5957
                  __tmp5956
                  __tmp5955
                  __tmp5954))))
          (if (and (integer?
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%value3053%_ 'coordinate)))
                   (exact? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%value3053%_ 'coordinate)))
                   (eq? (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%value3053%_ 'modality))
                        'observed))
              '#!void
              (let ()
                (declare (not safe))
                (error '"policy requires explicit observed integer coordinate")))
          _%value3053%_)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant-row
      (lambda (_%x3047%_)
        (let ((__tmp5959
               (lambda (_%s3049%_)
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%x3047%_ _%s3049%_)))))
          (declare (not safe))
          (##map __tmp5959
                 '(identity
                   domain-identity
                   coordinate
                   provenance-identity
                   modality)))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-policy
      (lambda (_%id2983%_ _%revision2984%_ _%start2985%_ _%end2986%_)
        (if (and (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#text?
                  _%id2983%_)
                 (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#text?
                  _%revision2984%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid support policy identity")))
        (let* ((_%a2988%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant
                 _%start2985%_))
               (_%b2990%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant
                 _%end2986%_))
               (_%domain2992%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%a2988%_ 'domain-identity))))
          (if (and (equal? _%domain2992%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%b2990%_
                              'domain-identity)))
                   (< (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%a2988%_ 'coordinate))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%b2990%_ 'coordinate))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"policy window must be nonempty in one time domain")))
          (let ((__tmp5960
                 (let ((__obj5947
                        (let ()
                          (declare (not safe))
                          (##structure
                           clan/poo/object#object::t
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp5962
                          (list (cons 'kind
                                      (let ((__tmp5963
                                             (lambda (_%self3015%_)
                                               'poo-flow.temporal-causality.support-policy)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5963)))
                                (cons 'identity
                                      (let ((__tmp5964
                                             (lambda (_%self3022%_)
                                               _%id2983%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5964)))
                                (cons 'revision-identity
                                      (let ((__tmp5965
                                             (lambda (_%self3027%_)
                                               _%revision2984%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5965)))
                                (cons 'start
                                      (let ((__tmp5966
                                             (lambda (_%self3032%_)
                                               _%a2988%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5966)))
                                (cons 'end
                                      (let ((__tmp5967
                                             (lambda (_%self3037%_)
                                               _%b2990%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5967)))
                                (cons 'semantic-digest
                                      (let ((__tmp5968
                                             (lambda (_%self3042%_)
                                               (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#digest
                                                (list 'poo-flow.temporal-support-policy.v1
                                                      _%id2983%_
                                                      _%revision2984%_
                                                      (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant-row
                                                       _%a2988%_)
                                                      (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant-row
                                                       _%b2990%_))))))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5968)))))
                         (__tmp5961 (list)))
                     (declare (not safe))
                     (clan/poo/object#object:::init!__%
                      '#f
                      '()
                      __tmp5962
                      __tmp5961
                      __obj5947))
                   __obj5947)))
            (declare (not safe))
            (clan/poo/mop#validate
             poo-flow/modules/temporal-causality/truth-maintenance/support/types#PooFlowTemporalSupportPolicy
             __tmp5960)))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#canonical-policy
      (lambda (_%policy2979%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%policy2979%_
                    'clan/poo/object#object::t))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot? _%policy2979%_ 'kind))
                 (eq? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%policy2979%_ 'kind))
                      'poo-flow.temporal-causality.support-policy))
            '#!void
            (let () (declare (not safe)) (error '"invalid support policy")))
        (let ((_%value2981%_
               (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-policy
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%policy2979%_ 'identity))
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%policy2979%_ 'revision-identity))
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%policy2979%_ 'start))
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%policy2979%_ 'end)))))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%value2981%_ 'semantic-digest))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%policy2979%_
                         'semantic-digest)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"support policy digest mismatch")))
          _%value2981%_)))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-guard
      (lambda (_%program2826%_
               _%journal2827%_
               _%as-of-value2828%_
               _%valid-at-value2829%_
               _%budget-value2830%_
               _%policy2831%_
               _%expected-digest2832%_
               _%effective-at2833%_)
        (if (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#text?
             _%expected-digest2832%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"expected policy digest required")))
        (let* ((_%owned2835%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#canonical-policy
                 _%policy2831%_))
               (_%now2837%_
                (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant
                 _%effective-at2833%_))
               (_%evaluation-value2839%_
                (let ()
                  (declare (not safe))
                  (poo-flow/modules/temporal-causality/truth-maintenance/support/funs#poo-flow-temporal-support-evaluate
                   _%program2826%_
                   _%journal2827%_
                   _%as-of-value2828%_
                   _%valid-at-value2829%_
                   _%budget-value2830%_)))
               (_%start2841%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%owned2835%_ 'start)))
               (_%end2843%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%owned2835%_ 'end))))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%now2837%_ 'domain-identity))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%start2841%_ 'domain-identity)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"policy evaluation time domain mismatch")))
          (if (equal? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%program2826%_
                         'policy-identity))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%owned2835%_ 'identity)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"support program policy owner mismatch")))
          (let* ((_%status2850%_
                  (if (equal? _%expected-digest2832%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%owned2835%_
                                 'semantic-digest)))
                      (if (< (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%now2837%_ 'coordinate))
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%start2841%_
                                'coordinate)))
                          'not-yet-effective
                          (if (>= (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%now2837%_
                                     'coordinate))
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%end2843%_
                                     'coordinate)))
                              'expired-policy
                              'applicable))
                      'stale-policy))
                 (_%fingerprint2852%_
                  (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#digest
                   (list 'poo-flow.temporal-support-guard.v1
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%evaluation-value2839%_
                            'semantic-digest))
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%owned2835%_
                            'semantic-digest))
                         _%expected-digest2832%_
                         (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#instant-row
                          _%now2837%_)
                         _%status2850%_)))
                 (__tmp5969
                  (let ((__obj5948
                         (let ()
                           (declare (not safe))
                           (##structure
                            clan/poo/object#object::t
                            '#f
                            '#f
                            '#f
                            '#f
                            '#f
                            '#f
                            '#f))))
                    (let ((__tmp5971
                           (list (cons 'kind
                                       (let ((__tmp5972
                                              (lambda (_%self2892%_)
                                                'poo-flow.temporal-causality.support-guard)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5972)))
                                 (cons 'semantic-digest
                                       (let ((__tmp5973
                                              (lambda (_%self2899%_)
                                                _%fingerprint2852%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5973)))
                                 (cons 'policy
                                       (let ((__tmp5974
                                              (lambda (_%self2904%_)
                                                _%owned2835%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5974)))
                                 (cons 'policy-digest
                                       (let ((__tmp5975
                                              (lambda (_%self2909%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%owned2835%_
                                                   'semantic-digest)))))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5975)))
                                 (cons 'expected-policy-digest
                                       (let ((__tmp5976
                                              (lambda (_%self2914%_)
                                                _%expected-digest2832%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5976)))
                                 (cons 'effective-at
                                       (let ((__tmp5977
                                              (lambda (_%self2919%_)
                                                _%now2837%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5977)))
                                 (cons 'policy-status
                                       (let ((__tmp5978
                                              (lambda (_%self2924%_)
                                                _%status2850%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5978)))
                                 (cons 'policy-applicable?
                                       (let ((__tmp5979
                                              (lambda (_%self2929%_)
                                                (eq? _%status2850%_
                                                     'applicable))))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5979)))
                                 (cons 'evaluation
                                       (let ((__tmp5980
                                              (lambda (_%self2934%_)
                                                _%evaluation-value2839%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5980)))
                                 (cons 'as-of
                                       (let ((__tmp5981
                                              (lambda (_%self2939%_)
                                                _%as-of-value2828%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5981)))
                                 (cons 'valid-at
                                       (let ((__tmp5982
                                              (lambda (_%self2944%_)
                                                _%valid-at-value2829%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5982)))
                                 (cons 'budget
                                       (let ((__tmp5983
                                              (lambda (_%self2949%_)
                                                _%budget-value2830%_)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5983)))
                                 (cons 'proof-admitted?
                                       (let ((__tmp5984
                                              (lambda (_%self2954%_) '#f)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5984)))
                                 (cons 'source-authenticated?
                                       (let ((__tmp5985
                                              (lambda (_%self2959%_) '#f)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5985)))
                                 (cons 'selection-admitted?
                                       (let ((__tmp5986
                                              (lambda (_%self2964%_) '#f)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5986)))
                                 (cons 'action-authorized?
                                       (let ((__tmp5987
                                              (lambda (_%self2969%_) '#f)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5987)))
                                 (cons 'durable?
                                       (let ((__tmp5988
                                              (lambda (_%self2974%_) '#f)))
                                         (declare (not safe))
                                         (##structure
                                          clan/poo/object#$self-slot-spec::t
                                          __tmp5988)))))
                          (__tmp5970 (list)))
                      (declare (not safe))
                      (clan/poo/object#object:::init!__%
                       '#f
                       '()
                       __tmp5971
                       __tmp5970
                       __obj5948))
                    __obj5948)))
            (declare (not safe))
            (clan/poo/mop#validate
             poo-flow/modules/temporal-causality/truth-maintenance/support/types#PooFlowTemporalSupportGuard
             __tmp5969)))))
    (define poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-guard-replay
      (lambda (_%receipt2819%_ _%program2820%_ _%journal2821%_ _%policy2822%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%receipt2819%_
                    'clan/poo/object#object::t))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.slot? _%receipt2819%_ 'kind))
                 (eq? (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%receipt2819%_ 'kind))
                      'poo-flow.temporal-causality.support-guard)
                 (if (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%receipt2819%_ 'proof-admitted?))
                     '#f
                     (if (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%receipt2819%_
                            'source-authenticated?))
                         '#f
                         (if (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%receipt2819%_
                                'selection-admitted?))
                             '#f
                             (if (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%receipt2819%_
                                    'action-authorized?))
                                 '#f
                                 (not (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%receipt2819%_
                                         'durable?))))))))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid support guard receipt")))
        (let ((_%value2824%_
               (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#poo-flow-temporal-support-guard
                _%program2820%_
                _%journal2821%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%receipt2819%_ 'as-of))
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%receipt2819%_ 'valid-at))
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%receipt2819%_ 'budget))
                _%policy2822%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref
                   _%receipt2819%_
                   'expected-policy-digest))
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%receipt2819%_ 'effective-at)))))
          (if (and (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%value2824%_
                              'semantic-digest))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%receipt2819%_
                              'semantic-digest)))
                   (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%value2824%_
                              'policy-digest))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%receipt2819%_
                              'policy-digest)))
                   (equal? (let ((__tmp5989
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%value2824%_
                                     'policy))))
                             (declare (not safe))
                             (clan/poo/object#.ref __tmp5989 'semantic-digest))
                           (let ((__tmp5990
                                  (poo-flow/modules/temporal-causality/truth-maintenance/support/policy#canonical-policy
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%receipt2819%_
                                      'policy)))))
                             (declare (not safe))
                             (clan/poo/object#.ref
                              __tmp5990
                              'semantic-digest)))
                   (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%value2824%_
                              'policy-status))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%receipt2819%_
                              'policy-status)))
                   (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%value2824%_
                              'policy-applicable?))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%receipt2819%_
                              'policy-applicable?)))
                   (equal? (let ((__tmp5991
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%value2824%_
                                     'evaluation))))
                             (declare (not safe))
                             (clan/poo/object#.ref __tmp5991 'semantic-digest))
                           (let ((__tmp5992
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%receipt2819%_
                                     'evaluation))))
                             (declare (not safe))
                             (clan/poo/object#.ref
                              __tmp5992
                              'semantic-digest))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"support guard replay binding mismatch")))
          _%value2824%_)))))
