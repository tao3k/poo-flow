(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/modules/temporal-causality/evaluator/rule::timestamp
    1791206457)
  (begin
    (define poo-flow/modules/temporal-causality/evaluator/rule#text?
      (lambda (_%x2893%_)
        (if (string? _%x2893%_)
            (< '0
               (let () (declare (not safe)) (##string-length _%x2893%_))
               '257)
            '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#name?
      (lambda (_%x2880%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#text?
             _%x2880%_)
            (let ((__tmp5725
                   (lambda (_%c2882%_)
                     (let ((_%$e2884%_ (char<=? '#\a _%c2882%_ '#\z)))
                       (if _%$e2884%_
                           _%$e2884%_
                           (let ((_%$e2887%_ (char<=? '#\A _%c2882%_ '#\Z)))
                             (if _%$e2887%_
                                 _%$e2887%_
                                 (let ((_%$e2890%_
                                        (char<=? '#\0 _%c2882%_ '#\9)))
                                   (if _%$e2890%_
                                       _%$e2890%_
                                       (eqv? _%c2882%_ '#\_)))))))))
                  (__tmp5724 (string->list _%x2880%_)))
              (declare (not safe))
              (andmap__0 __tmp5725 __tmp5724))
            '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#tag?
      (lambda (_%x2877%_ _%k2878%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of? _%x2877%_ 'clan/poo/object#object::t))
            (if (let ()
                  (declare (not safe))
                  (clan/poo/object#.slot? _%x2877%_ 'kind))
                (eq? (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%x2877%_ 'kind))
                     _%k2878%_)
                '#f)
            '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#bounded?
      (lambda (_%xs2874%_ _%n2875%_)
        (if (list? _%xs2874%_)
            (< '0
               (let () (declare (not safe)) (##length _%xs2874%_))
               (+ _%n2875%_ '1))
            '#f)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#digest
      (lambda (_%x2805%_)
        (let ((__tmp5726
               (let* ((_%bytes2825%_
                       (let* ((_%bytes2809%_
                               (let ((__tmp5727
                                      (call-with-output-string
                                       (lambda (_%p2807%_)
                                         (write _%x2805%_ _%p2807%_)))))
                                 (declare (not safe))
                                 (##string->utf8 __tmp5727)))
                              (_%bytes2814%_ _%bytes2809%_))
                         (declare (not safe))
                         (std/crypto/digest#__sha256 _%bytes2814%_)))
                      (_%start2828%_ '0)
                      (_%end2831%_
                       (let ()
                         (declare (not safe))
                         (##u8vector-length _%bytes2825%_)))
                      (_%bytes2836%_ _%bytes2825%_))
                 (if (and (let ()
                            (declare (not safe))
                            (##fx>= _%start2828%_ '0))
                          (let ((__tmp5728
                                 (let ((__tmp5729
                                        (let ()
                                          (declare (not safe))
                                          (##u8vector-length _%bytes2836%_))))
                                   (declare (not safe))
                                   (##fxmax __tmp5729 '1))))
                            (declare (not safe))
                            (##fx< _%start2828%_ __tmp5728)))
                     (let ((_%start2851%_ _%start2828%_))
                       (if (let ((__tmp5730
                                  (let ()
                                    (declare (not safe))
                                    (##u8vector-length _%bytes2836%_))))
                             (declare (not safe))
                             (##fx<= _%start2851%_ _%end2831%_ __tmp5730))
                           (let ((_%end2864%_ _%end2831%_))
                             (declare (not safe))
                             (std/encoding/hex#__hex-encode__%
                              _%bytes2836%_
                              _%start2851%_
                              _%end2864%_))
                           (begin
                             (raise-contract-violation-error
                              '"contract violation"
                              'context:
                              'poo-flow/modules/temporal-causality/evaluator/rule
                              'contract:
                              '(in-range-inclusive?
                                start
                                (u8vector-length bytes))
                              'value:
                              _%end2831%_)
                             '#!void)))
                     (begin
                       (raise-contract-violation-error
                        '"contract violation"
                        'context:
                        'poo-flow/modules/temporal-causality/evaluator/rule
                        'contract:
                        '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                        'value:
                        _%start2828%_)
                       '#!void)))))
          (declare (not safe))
          (##string-append '"sha256:" __tmp5726))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-relation
      (lambda (_%id-value2761%_ _%predicate-value2762%_ _%columns-value2763%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/rule#text?
                  _%id-value2761%_)
                 (poo-flow/modules/temporal-causality/evaluator/rule#name?
                  _%predicate-value2762%_)
                 (poo-flow/modules/temporal-causality/evaluator/rule#bounded?
                  _%columns-value2763%_
                  '32)
                 (let ((__tmp5731
                        (lambda (_%t2765%_)
                          (let ()
                            (declare (not safe))
                            (##memq _%t2765%_ '(integer boolean))))))
                   (declare (not safe))
                   (andmap__0 __tmp5731 _%columns-value2763%_)))
            '#!void
            (let () (declare (not safe)) (error '"invalid rule relation")))
        (let ((__obj5716
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp5733
                 (list (cons 'kind
                             (let ((__tmp5734
                                    (lambda (_%self2781%_)
                                      'temporal.rule-relation.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5734)))
                       (cons 'identity
                             (let ((__tmp5735
                                    (lambda (_%self2788%_)
                                      (string-copy _%id-value2761%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5735)))
                       (cons 'predicate
                             (let ((__tmp5736
                                    (lambda (_%self2793%_)
                                      (string-copy _%predicate-value2762%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5736)))
                       (cons 'columns
                             (let ((__tmp5737
                                    (lambda (_%self2798%_)
                                      (map (lambda (_%x2803%_) _%x2803%_)
                                           _%columns-value2763%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5737)))))
                (__tmp5732 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp5733
             __tmp5732
             __obj5716))
          __obj5716)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-variable
      (lambda (_%name-value2735%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#name?
             _%name-value2735%_)
            '#!void
            (let () (declare (not safe)) (error '"invalid rule variable")))
        (let ((__obj5717
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp5739
                 (list (cons 'kind
                             (let ((__tmp5740
                                    (lambda (_%self2749%_)
                                      'temporal.rule-variable.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5740)))
                       (cons 'name
                             (let ((__tmp5741
                                    (lambda (_%self2756%_)
                                      (string-copy _%name-value2735%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5741)))))
                (__tmp5738 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp5739
             __tmp5738
             __obj5717))
          __obj5717)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-literal
      (lambda (_%value-value2706%_)
        (if (or (boolean? _%value-value2706%_)
                (and (exact-integer? _%value-value2706%_)
                     (<= '-9223372036854775808
                         _%value-value2706%_
                         '9223372036854775807)))
            '#!void
            (let () (declare (not safe)) (error '"invalid rule literal")))
        (let ((__obj5718
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp5743
                 (list (cons 'kind
                             (let ((__tmp5744
                                    (lambda (_%self2723%_)
                                      'temporal.rule-literal.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5744)))
                       (cons 'value
                             (let ((__tmp5745
                                    (lambda (_%self2730%_)
                                      _%value-value2706%_)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5745)))))
                (__tmp5742 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp5743
             __tmp5742
             __obj5718))
          __obj5718)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#term-row
      (lambda (_%t2701%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
             _%t2701%_
             'temporal.rule-variable.v1)
            (let ()
              (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-variable
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%t2701%_ 'name)))
              (list 'variable
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%t2701%_ 'name))))
            (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
                 _%t2701%_
                 'temporal.rule-literal.v1)
                (let ()
                  (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-literal
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref _%t2701%_ 'value)))
                  (list 'literal
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%t2701%_ 'value))))
                (let () (declare (not safe)) (error '"invalid rule term"))))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-atom
      (lambda (_%relation-value2666%_ _%terms-value2667%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/rule#text?
                  _%relation-value2666%_)
                 (poo-flow/modules/temporal-causality/evaluator/rule#bounded?
                  _%terms-value2667%_
                  '32))
            '#!void
            (let () (declare (not safe)) (error '"invalid rule atom")))
        (for-each
         poo-flow/modules/temporal-causality/evaluator/rule#term-row
         _%terms-value2667%_)
        (let ((__obj5719
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp5747
                 (list (cons 'kind
                             (let ((__tmp5748
                                    (lambda (_%self2682%_)
                                      'temporal.rule-atom.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5748)))
                       (cons 'relation-identity
                             (let ((__tmp5749
                                    (lambda (_%self2689%_)
                                      (string-copy _%relation-value2666%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5749)))
                       (cons 'terms
                             (let ((__tmp5750
                                    (lambda (_%self2694%_)
                                      (map (lambda (_%x2699%_) _%x2699%_)
                                           _%terms-value2667%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5750)))))
                (__tmp5746 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp5747
             __tmp5746
             __obj5719))
          __obj5719)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#atom-row
      (lambda (_%a2664%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
             _%a2664%_
             'temporal.rule-atom.v1)
            '#!void
            (let () (declare (not safe)) (error '"invalid rule atom kind")))
        (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-atom
         (let ()
           (declare (not safe))
           (clan/poo/object#.ref _%a2664%_ 'relation-identity))
         (let () (declare (not safe)) (clan/poo/object#.ref _%a2664%_ 'terms)))
        (list (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%a2664%_ 'relation-identity))
              (map poo-flow/modules/temporal-causality/evaluator/rule#term-row
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref _%a2664%_ 'terms))))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule
      (lambda (_%id-value2622%_ _%head-value2623%_ _%body-value2624%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/rule#text?
                  _%id-value2622%_)
                 (poo-flow/modules/temporal-causality/evaluator/rule#bounded?
                  _%body-value2624%_
                  '32))
            '#!void
            (let () (declare (not safe)) (error '"invalid rule")))
        (poo-flow/modules/temporal-causality/evaluator/rule#atom-row
         _%head-value2623%_)
        (for-each
         poo-flow/modules/temporal-causality/evaluator/rule#atom-row
         _%body-value2624%_)
        (let ((__obj5720
               (let ()
                 (declare (not safe))
                 (##structure
                  clan/poo/object#object::t
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f
                  '#f))))
          (let ((__tmp5752
                 (list (cons 'kind
                             (let ((__tmp5753
                                    (lambda (_%self2640%_) 'temporal.rule.v1)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5753)))
                       (cons 'identity
                             (let ((__tmp5754
                                    (lambda (_%self2647%_)
                                      (string-copy _%id-value2622%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5754)))
                       (cons 'head
                             (let ((__tmp5755
                                    (lambda (_%self2652%_)
                                      _%head-value2623%_)))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5755)))
                       (cons 'body
                             (let ((__tmp5756
                                    (lambda (_%self2657%_)
                                      (map (lambda (_%x2662%_) _%x2662%_)
                                           _%body-value2624%_))))
                               (declare (not safe))
                               (##structure
                                clan/poo/object#$self-slot-spec::t
                                __tmp5756)))))
                (__tmp5751 (list)))
            (declare (not safe))
            (clan/poo/object#object:::init!__%
             '#f
             '()
             __tmp5752
             __tmp5751
             __obj5720))
          __obj5720)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#rule-row
      (lambda (_%r2620%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
             _%r2620%_
             'temporal.rule.v1)
            '#!void
            (let () (declare (not safe)) (error '"invalid rule kind")))
        (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule
         (let ()
           (declare (not safe))
           (clan/poo/object#.ref _%r2620%_ 'identity))
         (let () (declare (not safe)) (clan/poo/object#.ref _%r2620%_ 'head))
         (let () (declare (not safe)) (clan/poo/object#.ref _%r2620%_ 'body)))
        (list (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%r2620%_ 'identity))
              (poo-flow/modules/temporal-causality/evaluator/rule#atom-row
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%r2620%_ 'head)))
              (map poo-flow/modules/temporal-causality/evaluator/rule#atom-row
                   (let ()
                     (declare (not safe))
                     (clan/poo/object#.ref _%r2620%_ 'body))))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#relation-row
      (lambda (_%r2618%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
             _%r2618%_
             'temporal.rule-relation.v1)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid rule relation kind")))
        (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-relation
         (let ()
           (declare (not safe))
           (clan/poo/object#.ref _%r2618%_ 'identity))
         (let ()
           (declare (not safe))
           (clan/poo/object#.ref _%r2618%_ 'predicate))
         (let ()
           (declare (not safe))
           (clan/poo/object#.ref _%r2618%_ 'columns)))
        (list (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%r2618%_ 'identity))
              (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%r2618%_ 'predicate))
              (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%r2618%_ 'columns)))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#unique!
      (lambda (_%xs2565%_)
        (let ((_%seen2567%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%x2569%_)
             (if (let* ((_%h2571%_ _%seen2567%_)
                        (_%key2574%_ _%x2569%_)
                        (_%h2578%_ _%h2571%_)
                        (_%h2580%_ _%h2578%_))
                   (declare (not safe))
                   (__hash-get _%h2580%_ _%key2574%_))
                 (let ()
                   (declare (not safe))
                   (error '"duplicate rule correspondence"))
                 '#!void)
             (let* ((_%h2594%_ _%seen2567%_)
                    (_%key2597%_ _%x2569%_)
                    (_%value2600%_ '#t)
                    (_%h2604%_ _%h2594%_)
                    (_%h2606%_ _%h2604%_))
               (declare (not safe))
               (__hash-put! _%h2606%_ _%key2597%_ _%value2600%_)))
           _%xs2565%_))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#atom-clause
      (lambda (_%a2469%_ _%relations2470%_ _%variables2471%_ _%head?2472%_)
        (let* ((_%r2496%_
                (let* ((_%pred2476%_
                        (lambda (_%r2474%_)
                          (equal? (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref _%r2474%_ 'identity))
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%a2469%_
                                     'relation-identity)))))
                       (_%lst2479%_ _%relations2470%_)
                       (_%pred2484%_ _%pred2476%_))
                  (declare (not safe))
                  (__find _%pred2484%_ _%lst2479%_)))
               (_%ts2498%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%a2469%_ 'terms))))
          (if (and _%r2496%_
                   (= (length _%ts2498%_)
                      (length (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref _%r2496%_ 'columns)))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"missing relation or rule arity mismatch")))
          (cons (string->symbol
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%r2496%_ 'predicate)))
                (map (lambda (_%t2501%_ _%type2502%_)
                       (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
                            _%t2501%_
                            'temporal.rule-variable.v1)
                           (let* ((_%n2504%_
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref _%t2501%_ 'name)))
                                  (_%old2531%_
                                   (let* ((_%h2506%_ _%variables2471%_)
                                          (_%key2509%_ _%n2504%_)
                                          (_%h2513%_
                                           (let ()
                                             (declare (not safe))
                                             (cast HashTable::interface
                                                   _%h2506%_)))
                                          (_%h2515%_ _%h2513%_))
                                     (declare (not safe))
                                     (__hash-get _%h2515%_ _%key2509%_))))
                             (if (or (and _%head?2472%_ (not _%old2531%_))
                                     (and _%old2531%_
                                          (not (eq? _%old2531%_
                                                    _%type2502%_))))
                                 (let ()
                                   (declare (not safe))
                                   (error '"unbound or inconsistent rule variable"))
                                 '#!void)
                             (let* ((_%h2537%_ _%variables2471%_)
                                    (_%key2540%_ _%n2504%_)
                                    (_%value2543%_ _%type2502%_)
                                    (_%h2547%_
                                     (let ()
                                       (declare (not safe))
                                       (cast HashTable::interface _%h2537%_)))
                                    (_%h2549%_ _%h2547%_))
                               (declare (not safe))
                               (__hash-put!
                                _%h2549%_
                                _%key2540%_
                                _%value2543%_))
                             (let ((__tmp5757 (string-append '"?" _%n2504%_)))
                               (declare (not safe))
                               (##string->symbol __tmp5757)))
                           (let ((_%v2563%_
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref _%t2501%_ 'value))))
                             (if (if (eq? _%type2502%_ 'boolean)
                                     (boolean? _%v2563%_)
                                     (exact-integer? _%v2563%_))
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"rule literal column mismatch")))
                             _%v2563%_)))
                     _%ts2498%_
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%r2496%_ 'columns)))))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#rule-clause
      (lambda (_%r2457%_ _%relations2458%_)
        (let* ((_%variables2460%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value)))
               (_%body-value2464%_
                (map (lambda (_%a2462%_)
                       (poo-flow/modules/temporal-causality/evaluator/rule#atom-clause
                        _%a2462%_
                        _%relations2458%_
                        _%variables2460%_
                        '#f))
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%r2457%_ 'body))))
               (_%head-value2466%_
                (poo-flow/modules/temporal-causality/evaluator/rule#atom-clause
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%r2457%_ 'head))
                 _%relations2458%_
                 _%variables2460%_
                 '#t)))
          (cons _%head-value2466%_ _%body-value2464%_))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#PooFlowTemporalRuleProgram
      (let ((__obj5721
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp5759
               (list (cons 'sexp
                           (let ((__tmp5760
                                  (lambda (_%@2444%_)
                                    'PooFlowTemporalRuleProgram)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp5760)))
                     (cons '.element?
                           (let ((__tmp5761
                                  (lambda (_%@2450%_)
                                    (lambda (_%v2455%_)
                                      (poo-flow/modules/temporal-causality/evaluator/rule#tag?
                                       _%v2455%_
                                       'temporal.rule-program.v1)))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp5761)))))
              (__tmp5758 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           clan/poo/mop#Type.
           __tmp5759
           __tmp5758
           __obj5721))
        __obj5721))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-program
      (lambda (_%id-value2356%_
               _%catalog-value2357%_
               _%generation-value2358%_
               _%ascent-value2359%_
               _%relations-value2360%_
               _%rules-value2361%_)
        (if (and (poo-flow/modules/temporal-causality/evaluator/rule#text?
                  _%id-value2356%_)
                 (poo-flow/modules/temporal-causality/evaluator/rule#text?
                  _%catalog-value2357%_)
                 (poo-flow/modules/temporal-causality/evaluator/rule#text?
                  _%generation-value2358%_)
                 (exact-integer? _%ascent-value2359%_)
                 (<= '0 _%ascent-value2359%_)
                 (poo-flow/modules/temporal-causality/evaluator/rule#bounded?
                  _%relations-value2360%_
                  '32)
                 (poo-flow/modules/temporal-causality/evaluator/rule#bounded?
                  _%rules-value2361%_
                  '32))
            '#!void
            (let () (declare (not safe)) (error '"invalid rule program")))
        (let* ((_%relation-data2363%_
                (map poo-flow/modules/temporal-causality/evaluator/rule#relation-row
                     _%relations-value2360%_))
               (_%rule-data2365%_
                (map poo-flow/modules/temporal-causality/evaluator/rule#rule-row
                     _%rules-value2361%_)))
          (poo-flow/modules/temporal-causality/evaluator/rule#unique!
           (let () (declare (not safe)) (##map car _%relation-data2363%_)))
          (poo-flow/modules/temporal-causality/evaluator/rule#unique!
           (let () (declare (not safe)) (##map cadr _%relation-data2363%_)))
          (poo-flow/modules/temporal-causality/evaluator/rule#unique!
           (let () (declare (not safe)) (##map car _%rule-data2365%_)))
          (for-each
           (lambda (_%r2368%_)
             (poo-flow/modules/temporal-causality/evaluator/rule#rule-clause
              _%r2368%_
              _%relations-value2360%_))
           _%rules-value2361%_)
          (let ((__tmp5762
                 (let ((__obj5722
                        (let ()
                          (declare (not safe))
                          (##structure
                           clan/poo/object#object::t
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f
                           '#f))))
                   (let ((__tmp5764
                          (list (cons 'kind
                                      (let ((__tmp5765
                                             (lambda (_%self2391%_)
                                               'temporal.rule-program.v1)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5765)))
                                (cons 'identity
                                      (let ((__tmp5766
                                             (lambda (_%self2398%_)
                                               _%id-value2356%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5766)))
                                (cons 'catalog-digest
                                      (let ((__tmp5767
                                             (lambda (_%self2403%_)
                                               _%catalog-value2357%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5767)))
                                (cons 'generation
                                      (let ((__tmp5768
                                             (lambda (_%self2408%_)
                                               _%generation-value2358%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5768)))
                                (cons 'ascent-generation
                                      (let ((__tmp5769
                                             (lambda (_%self2413%_)
                                               _%ascent-value2359%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5769)))
                                (cons 'relations
                                      (let ((__tmp5770
                                             (lambda (_%self2418%_)
                                               _%relations-value2360%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5770)))
                                (cons 'rules
                                      (let ((__tmp5771
                                             (lambda (_%self2423%_)
                                               _%rules-value2361%_)))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5771)))
                                (cons 'semantic-digest
                                      (let ((__tmp5772
                                             (lambda (_%self2428%_)
                                               (poo-flow/modules/temporal-causality/evaluator/rule#digest
                                                (list 'temporal.rule-program.v1
                                                      _%id-value2356%_
                                                      _%catalog-value2357%_
                                                      _%generation-value2358%_
                                                      _%ascent-value2359%_
                                                      _%relation-data2363%_
                                                      _%rule-data2365%_)))))
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#$self-slot-spec::t
                                         __tmp5772)))))
                         (__tmp5763 (list)))
                     (declare (not safe))
                     (clan/poo/object#object:::init!__%
                      '#f
                      '()
                      __tmp5764
                      __tmp5763
                      __obj5722))
                   __obj5722)))
            (declare (not safe))
            (clan/poo/mop#validate
             poo-flow/modules/temporal-causality/evaluator/rule#PooFlowTemporalRuleProgram
             __tmp5762)))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-correspondence-from-ascent
      (lambda (_%program2186%_
               _%admission2187%_
               _%snapshot2188%_
               _%candidate2189%_
               _%receipt2190%_
               _%steps2191%_
               _%nodes2192%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
             _%program2186%_
             'temporal.rule-program.v1)
            '#!void
            (let () (declare (not safe)) (error '"invalid rule program kind")))
        (let* ((_%canonical2194%_
                (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-program
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2186%_ 'identity))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2186%_ 'catalog-digest))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2186%_ 'generation))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2186%_ 'ascent-generation))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2186%_ 'relations))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2186%_ 'rules))))
               (_%verified2196%_
                (let ()
                  (declare (not safe))
                  (poo-flow/modules/temporal-causality/evaluator/positive-proof#poo-flow-temporal-positive-proof-replay
                   _%admission2187%_
                   _%snapshot2188%_
                   _%candidate2189%_
                   _%receipt2190%_
                   _%steps2191%_
                   _%nodes2192%_)))
               (_%spec2198%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/program#candidate-inspect
                   _%snapshot2188%_
                   _%candidate2189%_)))
               (_%relations-value2200%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%canonical2194%_ 'relations)))
               (_%rules-value2202%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%canonical2194%_ 'rules)))
               (_%original-rules2204%_
                (##structure-ref
                 _%spec2198%_
                 '3
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)))
          (if (and (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%canonical2194%_
                              'semantic-digest))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%program2186%_
                              'semantic-digest)))
                   (= (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%canonical2194%_
                         'ascent-generation))
                      (##structure-ref
                       _%snapshot2188%_
                       '2
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                   (= (length _%original-rules2204%_)
                      (length _%rules-value2202%_)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"stale rule program or generation")))
          (let ((_%inventory2209%_
                 (append (map (lambda (_%r2207%_)
                                (cons (car _%r2207%_) (cadr _%r2207%_)))
                              (##structure-ref
                               _%snapshot2188%_
                               '4
                               gerbil-ascent/candidate/types#reasoning-snapshot::t
                               '#f))
                         (##structure-ref
                          _%spec2198%_
                          '1
                          gerbil-ascent/candidate/types#reasoning-candidate::t
                          '#f))))
            (if (and (= (let ()
                          (declare (not safe))
                          (##length _%inventory2209%_))
                        (length _%relations-value2200%_))
                     (let ((__tmp5773
                            (lambda (_%r2211%_)
                              (equal? (assq (string->symbol
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%r2211%_
                                                'predicate)))
                                            _%inventory2209%_)
                                      (cons (string->symbol
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%r2211%_
                                                'predicate)))
                                            (length (let ()
                                                      (declare (not safe))
                                                      (clan/poo/object#.ref
                                                       _%r2211%_
                                                       'columns))))))))
                       (declare (not safe))
                       (andmap__0 __tmp5773 _%relations-value2200%_)))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"rule catalog inventory mismatch"))))
          (for-each
           (lambda (_%r2213%_)
             (let ((_%declared2246%_
                    (let* ((_%pred2217%_
                            (lambda (_%d2215%_)
                              (eq? (string->symbol
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%d2215%_
                                       'predicate)))
                                   (car _%r2213%_))))
                           (_%lst2220%_ _%relations-value2200%_)
                           (_%pred2225%_ _%pred2217%_))
                      (declare (not safe))
                      (__find _%pred2225%_ _%lst2220%_))))
               (if (let ((__tmp5775
                          (lambda (_%row2248%_)
                            (let ((__tmp5777
                                   (lambda (_%v2250%_ _%type2251%_)
                                     (if (eq? _%type2251%_ 'boolean)
                                         (boolean? _%v2250%_)
                                         (and (exact-integer? _%v2250%_)
                                              (<= '-9223372036854775808
                                                  _%v2250%_
                                                  '9223372036854775807)))))
                                  (__tmp5776
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%declared2246%_
                                      'columns))))
                              (declare (not safe))
                              (andmap__1 __tmp5777 _%row2248%_ __tmp5776))))
                         (__tmp5774 (caddr _%r2213%_)))
                     (declare (not safe))
                     (andmap__0 __tmp5775 __tmp5774))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"source row type mismatch")))))
           (##structure-ref
            _%snapshot2188%_
            '4
            gerbil-ascent/candidate/types#reasoning-snapshot::t
            '#f))
          (for-each
           (lambda (_%r2253%_ _%original2254%_)
             (if (equal? (poo-flow/modules/temporal-causality/evaluator/rule#rule-clause
                          _%r2253%_
                          _%relations-value2200%_)
                         (cons (vector-ref _%original2254%_ '0)
                               (vector-ref _%original2254%_ '1)))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"original rule content does not match evaluator rule"))))
           _%rules-value2202%_
           _%original-rules2204%_)
          (let* ((_%applications-value2268%_
                  (let ((__tmp5779
                         (lambda (_%node2256%_)
                           (let _%loop2258%_ ((_%rs2260%_ _%rules-value2202%_)
                                              (_%os2261%_
                                               _%original-rules2204%_))
                             (if (null? _%rs2260%_)
                                 (let ()
                                   (declare (not safe))
                                   (error '"proof rule label missing"))
                                 (if (equal? (##structure-ref
                                              _%node2256%_
                                              '5
                                              gerbil-ascent/candidate/provenance#proof-node::t
                                              '#f)
                                             (vector-ref (car _%os2261%_) '2))
                                     (list (##structure-ref
                                            _%node2256%_
                                            '1
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            '#f)
                                           (let ((__tmp5780 (car _%rs2260%_)))
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              __tmp5780
                                              'identity)))
                                     (_%loop2258%_
                                      (cdr _%rs2260%_)
                                      (cdr _%os2261%_)))))))
                        (__tmp5778
                         (filter (lambda (_%n2266%_)
                                   (eq? (##structure-ref
                                         _%n2266%_
                                         '2
                                         gerbil-ascent/candidate/provenance#proof-node::t
                                         '#f)
                                        'rule))
                                 (##structure-ref
                                  (##structure-ref
                                   _%receipt2190%_
                                   '10
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f)
                                  '8
                                  gerbil-ascent/candidate/provenance#positive-proof::t
                                  '#f))))
                    (declare (not safe))
                    (##map __tmp5779 __tmp5778)))
                 (_%program-digest-value2270%_
                  (let ()
                    (declare (not safe))
                    (clan/poo/object#.ref _%canonical2194%_ 'semantic-digest)))
                 (_%proof-digest-value2272%_
                  (let ()
                    (declare (not safe))
                    (clan/poo/object#.ref _%verified2196%_ 'semantic-digest)))
                 (__obj5723
                  (let ()
                    (declare (not safe))
                    (##structure
                     clan/poo/object#object::t
                     '#f
                     '#f
                     '#f
                     '#f
                     '#f
                     '#f
                     '#f))))
            (let ((__tmp5782
                   (list (cons 'kind
                               (let ((__tmp5783
                                      (lambda (_%self2299%_)
                                        'temporal.rule-correspondence.v1)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5783)))
                         (cons 'program-digest
                               (let ((__tmp5784
                                      (lambda (_%self2306%_)
                                        _%program-digest-value2270%_)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5784)))
                         (cons 'proof-digest
                               (let ((__tmp5785
                                      (lambda (_%self2311%_)
                                        _%proof-digest-value2272%_)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5785)))
                         (cons 'generation
                               (let ((__tmp5786
                                      (lambda (_%self2316%_)
                                        (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%canonical2194%_
                                           'generation)))))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5786)))
                         (cons 'applications
                               (let ((__tmp5787
                                      (lambda (_%self2321%_)
                                        _%applications-value2268%_)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5787)))
                         (cons 'semantic-digest
                               (let ((__tmp5788
                                      (lambda (_%self2326%_)
                                        (poo-flow/modules/temporal-causality/evaluator/rule#digest
                                         (list 'temporal.rule-correspondence.v1
                                               _%program-digest-value2270%_
                                               _%proof-digest-value2272%_
                                               _%applications-value2268%_)))))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5788)))
                         (cons 'rule-correspondence-verified?
                               (let ((__tmp5789 (lambda (_%self2331%_) '#t)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5789)))
                         (cons 'source-authenticated?
                               (let ((__tmp5790 (lambda (_%self2336%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5790)))
                         (cons 'selection-admitted?
                               (let ((__tmp5791 (lambda (_%self2341%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5791)))
                         (cons 'action-authorized?
                               (let ((__tmp5792 (lambda (_%self2346%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5792)))
                         (cons 'durable?
                               (let ((__tmp5793 (lambda (_%self2351%_) '#f)))
                                 (declare (not safe))
                                 (##structure
                                  clan/poo/object#$self-slot-spec::t
                                  __tmp5793)))))
                  (__tmp5781 (list)))
              (declare (not safe))
              (clan/poo/object#object:::init!__%
               '#f
               '()
               __tmp5782
               __tmp5781
               __obj5723))
            __obj5723))))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-correspondence-replay
      (lambda (_%held2173%_
               _%program2174%_
               _%admission2175%_
               _%snapshot2176%_
               _%candidate2177%_
               _%receipt2178%_
               _%steps2179%_
               _%nodes2180%_)
        (if (poo-flow/modules/temporal-causality/evaluator/rule#tag?
             _%held2173%_
             'temporal.rule-correspondence.v1)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid rule correspondence kind")))
        (let ((_%canonical2182%_
               (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-correspondence-from-ascent
                _%program2174%_
                _%admission2175%_
                _%snapshot2176%_
                _%candidate2177%_
                _%receipt2178%_
                _%steps2179%_
                _%nodes2180%_)))
          (if (let ((__tmp5794
                     (lambda (_%s2184%_)
                       (and (let ()
                              (declare (not safe))
                              (clan/poo/object#.slot? _%held2173%_ _%s2184%_))
                            (equal? (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%held2173%_
                                       _%s2184%_))
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%canonical2182%_
                                       _%s2184%_)))))))
                (declare (not safe))
                (andmap__0
                 __tmp5794
                 '(program-digest
                   proof-digest
                   generation
                   applications
                   semantic-digest
                   rule-correspondence-verified?
                   source-authenticated?
                   selection-admitted?
                   action-authorized?
                   durable?)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"rule correspondence replay mismatch")))
          _%canonical2182%_)))
    (define poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-program-ascent-query
      (lambda (_%program2156%_ _%snapshot2157%_ _%output2158%_)
        (let* ((_%canonical2160%_
                (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-program
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2156%_ 'identity))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2156%_ 'catalog-digest))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2156%_ 'generation))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2156%_ 'ascent-generation))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2156%_ 'relations))
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%program2156%_ 'rules))))
               (_%source-names2162%_
                (map car
                     (##structure-ref
                      _%snapshot2157%_
                      '4
                      gerbil-ascent/candidate/types#reasoning-snapshot::t
                      '#f)))
               (_%relations2164%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%canonical2160%_ 'relations))))
          (if (and (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%canonical2160%_
                              'semantic-digest))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%program2156%_
                              'semantic-digest)))
                   (equal? (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%output2158%_ 'generation))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%canonical2160%_
                              'generation))))
              '#!void
              (let () (declare (not safe)) (error '"stale query projection")))
          (let ((__tmp5797
                 (let ((__tmp5800
                        (lambda (_%r2167%_)
                          (list 'relation
                                (string->symbol
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%r2167%_
                                    'predicate)))
                                (length (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%r2167%_
                                           'columns))))))
                       (__tmp5798
                        (filter (lambda (_%r2169%_)
                                  (not (let ((__tmp5799
                                              (string->symbol
                                               (let ()
                                                 (declare (not safe))
                                                 (clan/poo/object#.ref
                                                  _%r2169%_
                                                  'predicate)))))
                                         (declare (not safe))
                                         (##memq __tmp5799
                                                 _%source-names2162%_))))
                                _%relations2164%_)))
                   (declare (not safe))
                   (##map __tmp5800 __tmp5798)))
                (__tmp5796
                 (map (lambda (_%r2171%_)
                        (cons 'rule
                              (poo-flow/modules/temporal-causality/evaluator/rule#rule-clause
                               _%r2171%_
                               _%relations2164%_)))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%canonical2160%_ 'rules))))
                (__tmp5795
                 (list (cons 'query
                             (cons (string->symbol
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%output2158%_
                                       'evaluator-relation)))
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%output2158%_
                                      'row))))
                       '(limits 128 128 128))))
            (declare (not safe))
            (##append '(candidate) __tmp5797 __tmp5796 __tmp5795)))))))
