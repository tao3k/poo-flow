(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/src/ffi/temporal-support::timestamp 1791206433)
  (begin
    (define poo-flow/src/ffi/temporal-support#field
      (lambda (_%x2042%_ _%key2043%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2042%_ 'HashTable::t))
                 (let* ((_%h2045%_ _%x2042%_)
                        (_%k2048%_ _%key2043%_)
                        (_%h2052%_ _%h2045%_)
                        (_%h2054%_ _%h2052%_))
                   (declare (not safe))
                   (__hash-key? _%h2054%_ _%k2048%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"missing support field" _%key2043%_)))
        (let* ((_%h2066%_ _%x2042%_)
               (_%key2069%_ _%key2043%_)
               (_%default2072%_ absent-obj)
               (_%h2076%_
                (let ()
                  (declare (not safe))
                  (cast HashTable::interface _%h2066%_)))
               (_%h2078%_ _%h2076%_))
          (declare (not safe))
          (__hash-ref__% _%h2078%_ _%key2069%_ _%default2072%_))))
    (define poo-flow/src/ffi/temporal-support#fields
      (lambda (_%x2019%_ _%names2020%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2019%_ 'HashTable::t))
                 (= (let* ((_%h2022%_ _%x2019%_)
                           (_%h2026%_ _%h2022%_)
                           (_%h2028%_ _%h2026%_))
                      (declare (not safe))
                      (__hash-length _%h2028%_))
                    (length _%names2020%_)))
            '#!void
            (let () (declare (not safe)) (error '"unexpected support fields")))
        (for-each
         (lambda (_%key2040%_)
           (poo-flow/src/ffi/temporal-support#field _%x2019%_ _%key2040%_))
         _%names2020%_)))
    (define poo-flow/src/ffi/temporal-support#bounded-list
      (lambda (_%x2016%_ _%limit2017%_)
        (if (and (list? _%x2016%_)
                 (<= (let () (declare (not safe)) (##length _%x2016%_))
                     _%limit2017%_))
            '#!void
            (let () (declare (not safe)) (error '"support inventory bound")))
        _%x2016%_))
    (define poo-flow/src/ffi/temporal-support#instant
      (lambda (_%domain2013%_ _%position2014%_)
        (if (and (integer? _%position2014%_) (exact? _%position2014%_))
            '#!void
            (let () (declare (not safe)) (error '"support clock coordinate")))
        (let ((__tmp4911 (number->string _%position2014%_)))
          (declare (not safe))
          (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-instant
           __tmp4911
           _%domain2013%_
           _%position2014%_
           '"abi-caller"
           'observed))))
    (define poo-flow/src/ffi/temporal-support#temporal-support-input
      (lambda (_%x1989%_)
        (poo-flow/src/ffi/temporal-support#fields
         _%x1989%_
         (cons '"schema"
               (cons '"program"
                     (cons '"journal"
                           (cons '"asOf"
                                 (cons '"validAt" (cons '"budget" '())))))))
        (if (equal? (poo-flow/src/ffi/temporal-support#field
                     _%x1989%_
                     '"schema")
                    '"poo-flow.temporal-support-request.v1")
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported support schema")))
        (let* ((_%p1991%_
                (poo-flow/src/ffi/temporal-support#field _%x1989%_ '"program"))
               (_%j1993%_
                (poo-flow/src/ffi/temporal-support#field
                 _%x1989%_
                 '"journal")))
          (poo-flow/src/ffi/temporal-support#fields
           _%p1991%_
           (cons '"identity"
                 (cons '"policy" (cons '"complete" (cons '"supports" '())))))
          (poo-flow/src/ffi/temporal-support#fields
           _%j1993%_
           (cons '"identity"
                 (cons '"admissionDomain"
                       (cons '"validDomain" (cons '"revisions" '())))))
          (let* ((_%supports2000%_
                  (map (lambda (_%s1996%_)
                         (poo-flow/src/ffi/temporal-support#fields
                          _%s1996%_
                          (cons '"identity"
                                (cons '"conclusion"
                                      (cons '"proof"
                                            (cons '"premises"
                                                  (cons '"parents" '()))))))
                         (let ((__tmp4918
                                (poo-flow/src/ffi/temporal-support#field
                                 _%s1996%_
                                 '"identity"))
                               (__tmp4917
                                (poo-flow/src/ffi/temporal-support#field
                                 _%s1996%_
                                 '"conclusion"))
                               (__tmp4916
                                (poo-flow/src/ffi/temporal-support#field
                                 _%s1996%_
                                 '"proof"))
                               (__tmp4913
                                (map (lambda (_%v1998%_)
                                       (poo-flow/src/ffi/temporal-support#fields
                                        _%v1998%_
                                        (cons '"subject"
                                              (cons '"revision" '())))
                                       (let ((__tmp4915
                                              (poo-flow/src/ffi/temporal-support#field
                                               _%v1998%_
                                               '"subject"))
                                             (__tmp4914
                                              (poo-flow/src/ffi/temporal-support#field
                                               _%v1998%_
                                               '"revision")))
                                         (declare (not safe))
                                         (poo-flow/modules/temporal-causality/truth-maintenance/support/objects#poo-flow-temporal-support-premise
                                          __tmp4915
                                          __tmp4914)))
                                     (poo-flow/src/ffi/temporal-support#bounded-list
                                      (poo-flow/src/ffi/temporal-support#field
                                       _%s1996%_
                                       '"premises")
                                      '128)))
                               (__tmp4912
                                (poo-flow/src/ffi/temporal-support#bounded-list
                                 (poo-flow/src/ffi/temporal-support#field
                                  _%s1996%_
                                  '"parents")
                                 '128)))
                           (declare (not safe))
                           (poo-flow/modules/temporal-causality/truth-maintenance/support/objects#poo-flow-temporal-support
                            __tmp4918
                            __tmp4917
                            __tmp4916
                            __tmp4913
                            __tmp4912)))
                       (poo-flow/src/ffi/temporal-support#bounded-list
                        (poo-flow/src/ffi/temporal-support#field
                         _%p1991%_
                         '"supports")
                        '128)))
                 (_%program2002%_
                  (let ((__tmp4921
                         (poo-flow/src/ffi/temporal-support#field
                          _%p1991%_
                          '"identity"))
                        (__tmp4920
                         (poo-flow/src/ffi/temporal-support#field
                          _%p1991%_
                          '"policy"))
                        (__tmp4919
                         (poo-flow/src/ffi/temporal-support#field
                          _%p1991%_
                          '"complete")))
                    (declare (not safe))
                    (poo-flow/modules/temporal-causality/truth-maintenance/support/funs#poo-flow-temporal-support-program
                     __tmp4921
                     __tmp4920
                     __tmp4919
                     _%supports2000%_)))
                 (_%journal2004%_
                  (poo-flow/src/ffi/temporal-support#temporal-support-journal-input
                   _%j1993%_))
                 (_%valid2006%_
                  (poo-flow/src/ffi/temporal-support#field
                   _%x1989%_
                   '"validAt"))
                 (_%as-of2008%_
                  (poo-flow/src/ffi/temporal-support#instant
                   (poo-flow/src/ffi/temporal-support#field
                    _%j1993%_
                    '"admissionDomain")
                   (poo-flow/src/ffi/temporal-support#field
                    _%x1989%_
                    '"asOf")))
                 (_%valid-at2010%_
                  (if _%valid2006%_
                      (poo-flow/src/ffi/temporal-support#instant
                       (poo-flow/src/ffi/temporal-support#field
                        _%j1993%_
                        '"validDomain")
                       _%valid2006%_)
                      '#f)))
            (list _%program2002%_
                  _%journal2004%_
                  _%as-of2008%_
                  _%valid-at2010%_
                  (poo-flow/src/ffi/temporal-support#field
                   _%x1989%_
                   '"budget"))))))
    (define poo-flow/src/ffi/temporal-support#temporal-support-journal-input
      (lambda (_%j1969%_)
        (poo-flow/src/ffi/temporal-support#fields
         _%j1969%_
         (cons '"identity"
               (cons '"admissionDomain"
                     (cons '"validDomain" (cons '"revisions" '())))))
        (let ((_%revisions1986%_
               (map (lambda (_%r1971%_)
                      (poo-flow/src/ffi/temporal-support#fields
                       _%r1971%_
                       (cons '"identity"
                             (cons '"subject"
                                   (cons '"operation"
                                         (cons '"predecessor"
                                               (cons '"admitted"
                                                     (cons '"validRange"
                                                           (cons '"content"
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                      (let* ((_%operation1973%_
                              (poo-flow/src/ffi/temporal-support#field
                               _%r1971%_
                               '"operation"))
                             (_%op1979%_
                              (if (equal? _%operation1973%_ '"assert")
                                  'assert
                                  (if (equal? _%operation1973%_ '"correct")
                                      'correct
                                      (if (equal? _%operation1973%_ '"retract")
                                          'retract
                                          (let ()
                                            (declare (not safe))
                                            (error '"invalid support revision operation"))))))
                             (_%range1981%_
                              (poo-flow/src/ffi/temporal-support#field
                               _%r1971%_
                               '"validRange"))
                             (_%interval1983%_
                              (if _%range1981%_
                                  (begin
                                    (if (and (list? _%range1981%_)
                                             (= (let ()
                                                  (declare (not safe))
                                                  (##length _%range1981%_))
                                                '2))
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"invalid support validity range")))
                                    (let ((__tmp4924
                                           (poo-flow/src/ffi/temporal-support#field
                                            _%r1971%_
                                            '"identity"))
                                          (__tmp4923
                                           (poo-flow/src/ffi/temporal-support#instant
                                            (poo-flow/src/ffi/temporal-support#field
                                             _%j1969%_
                                             '"validDomain")
                                            (car _%range1981%_)))
                                          (__tmp4922
                                           (poo-flow/src/ffi/temporal-support#instant
                                            (poo-flow/src/ffi/temporal-support#field
                                             _%j1969%_
                                             '"validDomain")
                                            (cadr _%range1981%_))))
                                      (declare (not safe))
                                      (poo-flow/modules/temporal-causality/time/objects#poo-flow-temporal-interval
                                       __tmp4924
                                       __tmp4923
                                       __tmp4922
                                       '#t
                                       '#f)))
                                  '#f)))
                        (let ((__tmp4929
                               (poo-flow/src/ffi/temporal-support#field
                                _%r1971%_
                                '"identity"))
                              (__tmp4928
                               (poo-flow/src/ffi/temporal-support#field
                                _%r1971%_
                                '"subject"))
                              (__tmp4927
                               (poo-flow/src/ffi/temporal-support#field
                                _%r1971%_
                                '"predecessor"))
                              (__tmp4926
                               (poo-flow/src/ffi/temporal-support#instant
                                (poo-flow/src/ffi/temporal-support#field
                                 _%j1969%_
                                 '"admissionDomain")
                                (poo-flow/src/ffi/temporal-support#field
                                 _%r1971%_
                                 '"admitted")))
                              (__tmp4925
                               (poo-flow/src/ffi/temporal-support#field
                                _%r1971%_
                                '"content")))
                          (declare (not safe))
                          (poo-flow/modules/temporal-causality/revisions/objects#poo-flow-temporal-evidence-revision
                           __tmp4929
                           __tmp4928
                           _%op1979%_
                           __tmp4927
                           __tmp4926
                           _%interval1983%_
                           __tmp4925))))
                    (poo-flow/src/ffi/temporal-support#bounded-list
                     (poo-flow/src/ffi/temporal-support#field
                      _%j1969%_
                      '"revisions")
                     '128))))
          (let ((__tmp4931
                 (poo-flow/src/ffi/temporal-support#field
                  _%j1969%_
                  '"identity"))
                (__tmp4930
                 (poo-flow/src/ffi/temporal-support#field
                  _%j1969%_
                  '"admissionDomain")))
            (declare (not safe))
            (poo-flow/modules/temporal-causality/revisions/funs#poo-flow-temporal-evidence-journal
             __tmp4931
             __tmp4930
             _%revisions1986%_)))))
    (define poo-flow/src/ffi/temporal-support#temporal-support-call
      (lambda (_%x1967%_)
        (poo-flow/src/ffi/temporal-support#temporal-support-result
         (let ((__tmp4932
                (poo-flow/src/ffi/temporal-support#temporal-support-input
                 _%x1967%_)))
           (declare (not safe))
           (##apply poo-flow/modules/temporal-causality/truth-maintenance/support/funs#poo-flow-temporal-support-evaluate
                    __tmp4932)))))
    (define poo-flow/src/ffi/temporal-support#temporal-support-result
      (lambda (_%result1957%_)
        (let ((_%ht1959%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  '13
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (let ()
            (declare (not safe))
            (__hash-put!
             _%ht1959%_
             'schema
             '"poo-flow.temporal-support-result.v1"))
          (let () (declare (not safe)) (__hash-put! _%ht1959%_ 'abiVersion '1))
          (let ((__tmp4933
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'program-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'programDigest __tmp4933))
          (let ((__tmp4934
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'semantic-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'bindingDigest __tmp4934))
          (let ((__tmp4935
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'cut-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'cutDigest __tmp4935))
          (let ((__tmp4936
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'projection-digest))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'projectionDigest __tmp4936))
          (let ((__tmp4937
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref
                    _%result1957%_
                    'evaluated-support-count))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'evaluatedSupports __tmp4937))
          (let ((__tmp4938
                 (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%result1957%_ 'budget-exhausted?))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'budgetExhausted __tmp4938))
          (let ((__tmp4939
                 (map (lambda (_%r1962%_)
                        (let ((_%ht1964%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '3
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ((__tmp4940
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%r1962%_
                                    'identity))))
                            (declare (not safe))
                            (__hash-put! _%ht1964%_ 'identity __tmp4940))
                          (let ((__tmp4941
                                 (symbol->string
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%r1962%_
                                     'status)))))
                            (declare (not safe))
                            (__hash-put! _%ht1964%_ 'status __tmp4941))
                          (let ((__tmp4942
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%r1962%_
                                    'active-support-identities))))
                            (declare (not safe))
                            (__hash-put! _%ht1964%_ 'activeSupports __tmp4942))
                          _%ht1964%_))
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%result1957%_ 'conclusions)))))
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'conclusions __tmp4939))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'proofAdmitted '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'sourceAuthenticated '#f))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht1959%_ 'actionAuthorized '#f))
          (let () (declare (not safe)) (__hash-put! _%ht1959%_ 'durable '#f))
          _%ht1959%_)))))
