(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define poo-flow/src/ffi/temporal-proof::timestamp 1791206490)
  (begin
    (define poo-flow/src/ffi/temporal-proof#field
      (lambda (_%x2441%_ _%k2442%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2441%_ 'HashTable::t))
                 (let* ((_%h2444%_ _%x2441%_)
                        (_%k2447%_ _%k2442%_)
                        (_%h2451%_ _%h2444%_)
                        (_%h2453%_ _%h2451%_))
                   (declare (not safe))
                   (__hash-key? _%h2453%_ _%k2447%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"missing derivation field" _%k2442%_)))
        (let* ((_%h2465%_ _%x2441%_)
               (_%key2468%_ _%k2442%_)
               (_%default2471%_ absent-obj)
               (_%h2475%_
                (let ()
                  (declare (not safe))
                  (cast HashTable::interface _%h2465%_)))
               (_%h2477%_ _%h2475%_))
          (declare (not safe))
          (__hash-ref__% _%h2477%_ _%key2468%_ _%default2471%_))))
    (define poo-flow/src/ffi/temporal-proof#fields
      (lambda (_%x2419%_ _%ks2420%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-direct-instance-of? _%x2419%_ 'HashTable::t))
                 (= (let* ((_%h2422%_ _%x2419%_)
                           (_%h2426%_ _%h2422%_)
                           (_%h2428%_ _%h2426%_))
                      (declare (not safe))
                      (__hash-length _%h2428%_))
                    (length _%ks2420%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"unexpected derivation fields")))
        (for-each
         (lambda (_%k2439%_)
           (poo-flow/src/ffi/temporal-proof#field _%x2419%_ _%k2439%_))
         _%ks2420%_)))
    (define poo-flow/src/ffi/temporal-proof#bounded
      (lambda (_%x2416%_ _%n2417%_)
        (if (and (list? _%x2416%_)
                 (<= '1
                     (let () (declare (not safe)) (##length _%x2416%_))
                     _%n2417%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"derivation inventory bound")))
        _%x2416%_))
    (define poo-flow/src/ffi/temporal-proof#unique!
      (lambda (_%xs2363%_)
        (let ((_%seen2365%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%x2367%_)
             (if (let* ((_%h2369%_ _%seen2365%_)
                        (_%k2372%_ _%x2367%_)
                        (_%h2376%_ _%h2369%_)
                        (_%h2378%_ _%h2376%_))
                   (declare (not safe))
                   (__hash-key? _%h2378%_ _%k2372%_))
                 (let ()
                   (declare (not safe))
                   (error '"duplicate derivation identity"))
                 '#!void)
             (let* ((_%h2392%_ _%seen2365%_)
                    (_%key2395%_ _%x2367%_)
                    (_%value2398%_ '#t)
                    (_%h2402%_ _%h2392%_)
                    (_%h2404%_ _%h2402%_))
               (declare (not safe))
               (__hash-put! _%h2404%_ _%key2395%_ _%value2398%_)))
           _%xs2363%_))))
    (define poo-flow/src/ffi/temporal-proof#term
      (lambda (_%t2358%_)
        (let ((_%$e2360%_
               (string->symbol
                (poo-flow/src/ffi/temporal-proof#field _%t2358%_ '"kind"))))
          (if (eq? 'variable _%$e2360%_)
              (begin
                (poo-flow/src/ffi/temporal-proof#fields
                 _%t2358%_
                 (cons '"kind" (cons '"name" '())))
                (let ((__tmp5310
                       (poo-flow/src/ffi/temporal-proof#field
                        _%t2358%_
                        '"name")))
                  (declare (not safe))
                  (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-variable
                   __tmp5310)))
              (if (eq? 'literal _%$e2360%_)
                  (begin
                    (poo-flow/src/ffi/temporal-proof#fields
                     _%t2358%_
                     (cons '"kind" (cons '"value" '())))
                    (let ((__tmp5311
                           (poo-flow/src/ffi/temporal-proof#field
                            _%t2358%_
                            '"value")))
                      (declare (not safe))
                      (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-literal
                       __tmp5311)))
                  (let ()
                    (declare (not safe))
                    (error '"unsupported derivation term")))))))
    (define poo-flow/src/ffi/temporal-proof#atom
      (lambda (_%a2356%_)
        (poo-flow/src/ffi/temporal-proof#fields
         _%a2356%_
         (cons '"relationId" (cons '"terms" '())))
        (let ((__tmp5313
               (poo-flow/src/ffi/temporal-proof#field _%a2356%_ '"relationId"))
              (__tmp5312
               (map poo-flow/src/ffi/temporal-proof#term
                    (poo-flow/src/ffi/temporal-proof#bounded
                     (poo-flow/src/ffi/temporal-proof#field _%a2356%_ '"terms")
                     '32))))
          (declare (not safe))
          (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-atom
           __tmp5313
           __tmp5312))))
    (define poo-flow/src/ffi/temporal-proof#program
      (lambda (_%p2350%_)
        (poo-flow/src/ffi/temporal-proof#fields
         _%p2350%_
         (cons '"schema"
               (cons '"identity"
                     (cons '"catalogDigest"
                           (cons '"generation"
                                 (cons '"ascentGeneration"
                                       (cons '"relations"
                                             (cons '"rules" '()))))))))
        (if (equal? (poo-flow/src/ffi/temporal-proof#field _%p2350%_ '"schema")
                    '"poo-flow.mrr-rule-program.v1")
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported rule projection schema")))
        (let ((__tmp5325
               (poo-flow/src/ffi/temporal-proof#field _%p2350%_ '"identity"))
              (__tmp5324
               (poo-flow/src/ffi/temporal-proof#field
                _%p2350%_
                '"catalogDigest"))
              (__tmp5323
               (poo-flow/src/ffi/temporal-proof#field _%p2350%_ '"generation"))
              (__tmp5322
               (poo-flow/src/ffi/temporal-proof#field
                _%p2350%_
                '"ascentGeneration"))
              (__tmp5318
               (map (lambda (_%r2352%_)
                      (poo-flow/src/ffi/temporal-proof#fields
                       _%r2352%_
                       (cons '"identity"
                             (cons '"predicate" (cons '"columns" '()))))
                      (let ((__tmp5321
                             (poo-flow/src/ffi/temporal-proof#field
                              _%r2352%_
                              '"identity"))
                            (__tmp5320
                             (poo-flow/src/ffi/temporal-proof#field
                              _%r2352%_
                              '"predicate"))
                            (__tmp5319
                             (map string->symbol
                                  (poo-flow/src/ffi/temporal-proof#bounded
                                   (poo-flow/src/ffi/temporal-proof#field
                                    _%r2352%_
                                    '"columns")
                                   '32))))
                        (declare (not safe))
                        (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-relation
                         __tmp5321
                         __tmp5320
                         __tmp5319)))
                    (poo-flow/src/ffi/temporal-proof#bounded
                     (poo-flow/src/ffi/temporal-proof#field
                      _%p2350%_
                      '"relations")
                     '32)))
              (__tmp5314
               (map (lambda (_%r2354%_)
                      (poo-flow/src/ffi/temporal-proof#fields
                       _%r2354%_
                       (cons '"identity" (cons '"head" (cons '"body" '()))))
                      (let ((__tmp5317
                             (poo-flow/src/ffi/temporal-proof#field
                              _%r2354%_
                              '"identity"))
                            (__tmp5316
                             (poo-flow/src/ffi/temporal-proof#atom
                              (poo-flow/src/ffi/temporal-proof#field
                               _%r2354%_
                               '"head")))
                            (__tmp5315
                             (map poo-flow/src/ffi/temporal-proof#atom
                                  (poo-flow/src/ffi/temporal-proof#bounded
                                   (poo-flow/src/ffi/temporal-proof#field
                                    _%r2354%_
                                    '"body")
                                   '32))))
                        (declare (not safe))
                        (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule
                         __tmp5317
                         __tmp5316
                         __tmp5315)))
                    (poo-flow/src/ffi/temporal-proof#bounded
                     (poo-flow/src/ffi/temporal-proof#field _%p2350%_ '"rules")
                     '32))))
          (declare (not safe))
          (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-program
           __tmp5325
           __tmp5324
           __tmp5323
           __tmp5322
           __tmp5318
           __tmp5314))))
    (define poo-flow/src/ffi/temporal-proof#fact
      (lambda (_%f2348%_)
        (poo-flow/src/ffi/temporal-proof#fields
         _%f2348%_
         (cons '"schema"
               (cons '"identity"
                     (cons '"generation"
                           (cons '"relationId"
                                 (cons '"evaluatorRelation"
                                       (cons '"row" '())))))))
        (if (equal? (poo-flow/src/ffi/temporal-proof#field _%f2348%_ '"schema")
                    '"poo-flow.mrr-fact-request.v1")
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported fact projection schema")))
        (let ((__tmp5330
               (poo-flow/src/ffi/temporal-proof#field _%f2348%_ '"identity"))
              (__tmp5329
               (poo-flow/src/ffi/temporal-proof#field _%f2348%_ '"generation"))
              (__tmp5328
               (poo-flow/src/ffi/temporal-proof#field _%f2348%_ '"relationId"))
              (__tmp5327
               (poo-flow/src/ffi/temporal-proof#field
                _%f2348%_
                '"evaluatorRelation"))
              (__tmp5326
               (poo-flow/src/ffi/temporal-proof#bounded
                (poo-flow/src/ffi/temporal-proof#field _%f2348%_ '"row")
                '32)))
          (declare (not safe))
          (poo-flow/modules/temporal-causality/evaluator/fact#poo-flow-temporal-mrr-fact-content
           __tmp5330
           __tmp5329
           __tmp5328
           __tmp5327
           __tmp5326))))
    (define poo-flow/src/ffi/temporal-proof#temporal-derivation-admit
      (lambda (_%request2068%_)
        (poo-flow/src/ffi/temporal-proof#fields
         _%request2068%_
         (cons '"schema"
               (cons '"projection"
                     (cons '"journal"
                           (cons '"sourceBindings"
                                 (cons '"workSteps"
                                       (cons '"maximumNodes" '())))))))
        (if (equal? (poo-flow/src/ffi/temporal-proof#field
                     _%request2068%_
                     '"schema")
                    '"poo-flow.temporal-derivation-admit-request.v1")
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported derivation admit schema")))
        (let* ((_%data2070%_
                (poo-flow/src/ffi/temporal-proof#field
                 _%request2068%_
                 '"projection"))
               (_%steps2072%_
                (poo-flow/src/ffi/temporal-proof#field
                 _%request2068%_
                 '"workSteps"))
               (_%max-nodes2074%_
                (poo-flow/src/ffi/temporal-proof#field
                 _%request2068%_
                 '"maximumNodes")))
          (poo-flow/src/ffi/temporal-proof#fields
           _%data2070%_
           (cons '"schema"
                 (cons '"identity"
                       (cons '"program"
                             (cons '"rootFact"
                                   (cons '"facts"
                                         (cons '"derivations" '())))))))
          (if (and (equal? (poo-flow/src/ffi/temporal-proof#field
                            _%data2070%_
                            '"schema")
                           '"poo-flow.mrr-derivation-projection.v1")
                   (exact-integer? _%steps2072%_)
                   (<= '1 _%steps2072%_ '4096)
                   (exact-integer? _%max-nodes2074%_)
                   (<= '1 _%max-nodes2074%_ '128))
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid derivation proof bounds")))
          (let* ((_%owned-program2077%_
                  (poo-flow/src/ffi/temporal-proof#program
                   (poo-flow/src/ffi/temporal-proof#field
                    _%data2070%_
                    '"program")))
                 (_%original-facts2079%_
                  (poo-flow/src/ffi/temporal-proof#bounded
                   (poo-flow/src/ffi/temporal-proof#field
                    _%data2070%_
                    '"facts")
                   '128))
                 (_%facts2085%_
                  (map (lambda (_%row2081%_)
                         (poo-flow/src/ffi/temporal-proof#fields
                          _%row2081%_
                          (cons '"content"
                                (cons '"contentDigest" (cons '"source" '()))))
                         (if (boolean?
                              (poo-flow/src/ffi/temporal-proof#field
                               _%row2081%_
                               '"source"))
                             '#!void
                             (let ()
                               (declare (not safe))
                               (error '"invalid fact source marker")))
                         (let ((_%f2083%_
                                (poo-flow/src/ffi/temporal-proof#fact
                                 (poo-flow/src/ffi/temporal-proof#field
                                  _%row2081%_
                                  '"content"))))
                           (if (and (equal? (let ()
                                              (declare (not safe))
                                              (clan/poo/object#.ref
                                               _%f2083%_
                                               'semantic-digest))
                                            (poo-flow/src/ffi/temporal-proof#field
                                             _%row2081%_
                                             '"contentDigest"))
                                    (equal? (let ()
                                              (declare (not safe))
                                              (clan/poo/object#.ref
                                               _%f2083%_
                                               'generation))
                                            (let ()
                                              (declare (not safe))
                                              (clan/poo/object#.ref
                                               _%owned-program2077%_
                                               'generation))))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"fact digest or generation mismatch")))
                           _%f2083%_))
                       _%original-facts2079%_))
                 (_%get-fact2123%_
                  (lambda (_%id2087%_)
                    (let ((_%$e2120%_
                           (let* ((_%pred2091%_
                                   (lambda (_%f2089%_)
                                     (equal? (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%f2089%_
                                                'identity))
                                             _%id2087%_)))
                                  (_%lst2094%_ _%facts2085%_)
                                  (_%pred2099%_ _%pred2091%_))
                             (declare (not safe))
                             (__find _%pred2099%_ _%lst2094%_))))
                      (if _%$e2120%_
                          _%$e2120%_
                          (let ()
                            (declare (not safe))
                            (error '"unknown original fact"))))))
                 (_%derivations2127%_
                  (map (lambda (_%d2125%_)
                         (poo-flow/src/ffi/temporal-proof#fields
                          _%d2125%_
                          (cons '"identity"
                                (cons '"rule"
                                      (cons '"generation"
                                            (cons '"output"
                                                  (cons '"supports" '()))))))
                         (let ((__tmp5335
                                (poo-flow/src/ffi/temporal-proof#field
                                 _%d2125%_
                                 '"identity"))
                               (__tmp5334
                                (poo-flow/src/ffi/temporal-proof#field
                                 _%d2125%_
                                 '"rule"))
                               (__tmp5333
                                (poo-flow/src/ffi/temporal-proof#field
                                 _%d2125%_
                                 '"generation"))
                               (__tmp5332
                                (_%get-fact2123%_
                                 (poo-flow/src/ffi/temporal-proof#field
                                  _%d2125%_
                                  '"output")))
                               (__tmp5331
                                (poo-flow/src/ffi/temporal-proof#bounded
                                 (poo-flow/src/ffi/temporal-proof#field
                                  _%d2125%_
                                  '"supports")
                                 '128)))
                           (declare (not safe))
                           (poo-flow/modules/temporal-causality/evaluator/derivation#poo-flow-temporal-mrr-derivation
                            __tmp5335
                            __tmp5334
                            __tmp5333
                            __tmp5332
                            __tmp5331)))
                       (poo-flow/src/ffi/temporal-proof#bounded
                        (poo-flow/src/ffi/temporal-proof#field
                         _%data2070%_
                         '"derivations")
                        '128)))
                 (_%source-facts2134%_
                  (let ((__tmp5338 (lambda (_%x2129%_) _%x2129%_))
                        (__tmp5336
                         (let ((__tmp5337
                                (lambda (_%f2131%_ _%row2132%_)
                                  (if (poo-flow/src/ffi/temporal-proof#field
                                       _%row2132%_
                                       '"source")
                                      _%f2131%_
                                      '#f))))
                           (declare (not safe))
                           (##map __tmp5337
                                  _%facts2085%_
                                  _%original-facts2079%_))))
                    (declare (not safe))
                    (##filter __tmp5338 __tmp5336)))
                 (_%output2136%_
                  (_%get-fact2123%_
                   (poo-flow/src/ffi/temporal-proof#field
                    _%data2070%_
                    '"rootFact")))
                 (_%journal2138%_
                  (let ((__tmp5339
                         (poo-flow/src/ffi/temporal-proof#field
                          _%request2068%_
                          '"journal")))
                    (declare (not safe))
                    (poo-flow/src/ffi/temporal-support#temporal-support-journal-input
                     __tmp5339))))
            (let ((__tmp5340
                   (lambda (_%f2141%_)
                     (let ((_%r2171%_
                            (let* ((_%pred2145%_
                                    (lambda (_%r2143%_)
                                      (equal? (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 _%r2143%_
                                                 'identity))
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 _%f2141%_
                                                 'relation-identity)))))
                                   (_%lst2148%_
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%owned-program2077%_
                                       'relations)))
                                   (_%pred2153%_ _%pred2145%_))
                              (declare (not safe))
                              (__find _%pred2153%_ _%lst2148%_))))
                       (if (and _%r2171%_
                                (equal? (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%r2171%_
                                           'predicate))
                                        (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%f2141%_
                                           'evaluator-relation)))
                                (= (length (let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%r2171%_
                                              'columns)))
                                   (length (let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%f2141%_
                                              'row))))
                                (let ((__tmp5343
                                       (lambda (_%v2173%_ _%t2174%_)
                                         (if (eq? _%t2174%_ 'boolean)
                                             (boolean? _%v2173%_)
                                             (exact-integer? _%v2173%_))))
                                      (__tmp5342
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%f2141%_
                                          'row)))
                                      (__tmp5341
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%r2171%_
                                          'columns))))
                                  (declare (not safe))
                                  (andmap__1 __tmp5343 __tmp5342 __tmp5341)))
                           '#!void
                           (let ()
                             (declare (not safe))
                             (error '"fact catalog row mismatch")))))))
              (declare (not safe))
              (##for-each __tmp5340 _%facts2085%_))
            (poo-flow/src/ffi/temporal-proof#unique!
             (let ((__tmp5344
                    (lambda (_%f2176%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%f2176%_ 'identity)))))
               (declare (not safe))
               (##map __tmp5344 _%facts2085%_)))
            (poo-flow/src/ffi/temporal-proof#unique!
             (let ((__tmp5345
                    (lambda (_%d2178%_)
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%d2178%_ 'identity)))))
               (declare (not safe))
               (##map __tmp5345 _%derivations2127%_)))
            (poo-flow/src/ffi/temporal-proof#unique!
             (let ((__tmp5346
                    (lambda (_%d2180%_)
                      (let ((__tmp5347
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%d2180%_ 'output))))
                        (declare (not safe))
                        (clan/poo/object#.ref __tmp5347 'identity)))))
               (declare (not safe))
               (##map __tmp5346 _%derivations2127%_)))
            (if (pair? _%source-facts2134%_)
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"proof requires source facts")))
            (let ((__tmp5348
                   (lambda (_%f2182%_ _%row2183%_)
                     (if (eq? (poo-flow/src/ffi/temporal-proof#field
                               _%row2183%_
                               '"source")
                              (not (let* ((_%pred2187%_
                                           (lambda (_%d2185%_)
                                             (equal? (let ((__tmp5349
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (clan/poo/object#.ref
                                                               _%d2185%_
                                                               'output))))
                                                       (declare (not safe))
                                                       (clan/poo/object#.ref
                                                        __tmp5349
                                                        'identity))
                                                     (let ()
                                                       (declare (not safe))
                                                       (clan/poo/object#.ref
                                                        _%f2182%_
                                                        'identity)))))
                                          (_%lst2190%_ _%derivations2127%_)
                                          (_%pred2195%_ _%pred2187%_))
                                     (declare (not safe))
                                     (__find _%pred2195%_ _%lst2190%_))))
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"source marker and derivation authority differ"))))))
              (declare (not safe))
              (##for-each __tmp5348 _%facts2085%_ _%original-facts2079%_))
            (let* ((_%snapshot2215%_
                    (let ((__tmp5357
                           (string->symbol
                            (poo-flow/src/ffi/temporal-proof#field
                             _%data2070%_
                             '"identity")))
                          (__tmp5356
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%owned-program2077%_
                              'ascent-generation)))
                          (__tmp5350
                           (let ((__tmp5352
                                  (lambda (_%r2207%_)
                                    (let ((_%rows2213%_
                                           (let ((__tmp5355
                                                  (lambda (_%f2209%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (clan/poo/object#.ref
                                                       _%f2209%_
                                                       'row))))
                                                 (__tmp5353
                                                  (let ((__tmp5354
                                                         (lambda (_%f2211%_)
                                                           (equal? (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%f2211%_
                              'relation-identity))
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%r2207%_ 'identity))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (declare (not safe))
                                                    (##filter
                                                     __tmp5354
                                                     _%source-facts2134%_))))
                                             (declare (not safe))
                                             (##map __tmp5355 __tmp5353))))
                                      (if (pair? _%rows2213%_)
                                          (list (string->symbol
                                                 (let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%r2207%_
                                                    'predicate)))
                                                (length (let ()
                                                          (declare (not safe))
                                                          (clan/poo/object#.ref
                                                           _%r2207%_
                                                           'columns)))
                                                _%rows2213%_)
                                          '#f))))
                                 (__tmp5351
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%owned-program2077%_
                                     'relations))))
                             (declare (not safe))
                             (filter-map__0 __tmp5352 __tmp5351))))
                      (declare (not safe))
                      (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
                       __tmp5357
                       __tmp5356
                       __tmp5350)))
                   (_%candidate2217%_
                    (let ()
                      (declare (not safe))
                      (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-program-ascent-query
                       _%owned-program2077%_
                       _%snapshot2215%_
                       _%output2136%_)))
                   (_%receipt2219%_
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                       _%snapshot2215%_
                       _%candidate2217%_
                       _%steps2072%_)))
                   (_%admission2221%_
                    (let ((__tmp5358
                           (poo-flow/src/ffi/temporal-proof#field
                            _%data2070%_
                            '"identity")))
                      (declare (not safe))
                      (poo-flow/modules/temporal-causality/evaluator/positive-proof#poo-flow-temporal-positive-proof-from-ascent
                       __tmp5358
                       _%snapshot2215%_
                       _%candidate2217%_
                       _%receipt2219%_
                       _%steps2072%_
                       _%max-nodes2074%_)))
                   (_%nodes2223%_
                    (##structure-ref
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref _%receipt2219%_ '10 '#f '#f))
                     '8
                     gerbil-ascent/candidate/provenance#positive-proof::t
                     '#f))
                   (_%node-bindings2262%_
                    (let ((__tmp5359
                           (lambda (_%f2225%_)
                             (let* ((_%matches2229%_
                                     (filter (lambda (_%n2227%_)
                                               (if (equal? (##structure-ref
                                                            _%n2227%_
                                                            '4
                                                            gerbil-ascent/candidate/provenance#proof-node::t
                                                            '#f)
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (clan/poo/object#.ref
                                                              _%f2225%_
                                                              'row)))
                                                   (equal? (symbol->string
                                                            (##structure-ref
                                                             _%n2227%_
                                                             '3
                                                             gerbil-ascent/candidate/provenance#proof-node::t
                                                             '#f))
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (clan/poo/object#.ref
                                                              _%f2225%_
                                                              'evaluator-relation)))
                                                   '#f))
                                             _%nodes2223%_))
                                    (_%d2259%_
                                     (let* ((_%pred2233%_
                                             (lambda (_%d2231%_)
                                               (equal? (let ((__tmp5360
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (clan/poo/object#.ref _%d2231%_ 'output))))
                 (declare (not safe))
                 (clan/poo/object#.ref __tmp5360 'identity))
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%f2225%_ 'identity)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (_%lst2236%_ _%derivations2127%_)
                                            (_%pred2241%_ _%pred2233%_))
                                       (declare (not safe))
                                       (__find _%pred2241%_ _%lst2236%_))))
                               (if (= (let ()
                                        (declare (not safe))
                                        (##length _%matches2229%_))
                                      '1)
                                   '#!void
                                   (let ()
                                     (declare (not safe))
                                     (error '"ambiguous or absent proof fact correspondence")))
                               (let ((__tmp5361
                                      (##structure-ref
                                       (car _%matches2229%_)
                                       '1
                                       gerbil-ascent/candidate/provenance#proof-node::t
                                       '#f)))
                                 (declare (not safe))
                                 (poo-flow/modules/temporal-causality/evaluator/derivation#poo-flow-temporal-proof-node-fact
                                  __tmp5361
                                  _%f2225%_
                                  _%d2259%_))))))
                      (declare (not safe))
                      (##map __tmp5359 _%facts2085%_)))
                   (_%source-inputs2264%_
                    (poo-flow/src/ffi/temporal-proof#bounded
                     (poo-flow/src/ffi/temporal-proof#field
                      _%request2068%_
                      '"sourceBindings")
                     '128))
                   (_%source-bindings2298%_
                    (map (lambda (_%b2266%_)
                           (poo-flow/src/ffi/temporal-proof#fields
                            _%b2266%_
                            (cons '"fact"
                                  (cons '"subject" (cons '"revision" '()))))
                           (let* ((_%f2268%_
                                   (_%get-fact2123%_
                                    (poo-flow/src/ffi/temporal-proof#field
                                     _%b2266%_
                                     '"fact")))
                                  (_%node2295%_
                                   (let* ((_%pred2272%_
                                           (lambda (_%n2270%_)
                                             (equal? (let ((__tmp5362
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (clan/poo/object#.ref
                                                               _%n2270%_
                                                               'fact))))
                                                       (declare (not safe))
                                                       (clan/poo/object#.ref
                                                        __tmp5362
                                                        'identity))
                                                     (let ()
                                                       (declare (not safe))
                                                       (clan/poo/object#.ref
                                                        _%f2268%_
                                                        'identity)))))
                                          (_%lst2275%_ _%node-bindings2262%_)
                                          (_%pred2280%_ _%pred2272%_))
                                     (declare (not safe))
                                     (__find _%pred2280%_ _%lst2275%_))))
                             (if (let ()
                                   (declare (not safe))
                                   (##member _%f2268%_ _%source-facts2134%_))
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"binding is not an original source")))
                             (let ((__tmp5365
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%node2295%_
                                       'node)))
                                   (__tmp5364
                                    (poo-flow/src/ffi/temporal-proof#field
                                     _%b2266%_
                                     '"subject"))
                                   (__tmp5363
                                    (poo-flow/src/ffi/temporal-proof#field
                                     _%b2266%_
                                     '"revision")))
                               (declare (not safe))
                               (poo-flow/modules/temporal-causality/evaluator/binding#poo-flow-temporal-proof-source-binding
                                __tmp5365
                                _%f2268%_
                                __tmp5364
                                __tmp5363))))
                         _%source-inputs2264%_))
                   (_%roots2300%_
                    (##structure-ref
                     (let ()
                       (declare (not safe))
                       (##unchecked-structure-ref _%receipt2219%_ '10 '#f '#f))
                     '9
                     gerbil-ascent/candidate/provenance#positive-proof::t
                     '#f))
                   (_%root-d2325%_
                    (let* ((_%pred2304%_
                            (lambda (_%d2302%_)
                              (equal? (let ((__tmp5366
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%d2302%_
                                                'output))))
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         __tmp5366
                                         'identity))
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%output2136%_
                                         'identity)))))
                           (_%lst2307%_ _%derivations2127%_)
                           (_%pred2312%_ _%pred2304%_))
                      (declare (not safe))
                      (__find _%pred2312%_ _%lst2307%_))))
              (if (and _%root-d2325%_ (= (length _%roots2300%_) '1))
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"selected original derived root required")))
              (let* ((_%bound2328%_
                      (let ((__tmp5368
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%root-d2325%_
                                'identity)))
                            (__tmp5367 (car _%roots2300%_)))
                        (declare (not safe))
                        (poo-flow/modules/temporal-causality/evaluator/binding#poo-flow-temporal-proof-support
                         __tmp5368
                         _%admission2221%_
                         _%snapshot2215%_
                         _%candidate2217%_
                         _%receipt2219%_
                         _%steps2072%_
                         _%max-nodes2074%_
                         __tmp5367
                         _%output2136%_
                         _%source-bindings2298%_
                         _%journal2138%_)))
                     (_%correspondence2330%_
                      (let ()
                        (declare (not safe))
                        (poo-flow/modules/temporal-causality/evaluator/rule#poo-flow-temporal-rule-correspondence-from-ascent
                         _%owned-program2077%_
                         _%admission2221%_
                         _%snapshot2215%_
                         _%candidate2217%_
                         _%receipt2219%_
                         _%steps2072%_
                         _%max-nodes2074%_)))
                     (_%joint2332%_
                      (let ((__tmp5369
                             (poo-flow/src/ffi/temporal-proof#field
                              _%data2070%_
                              '"identity")))
                        (declare (not safe))
                        (poo-flow/modules/temporal-causality/evaluator/derivation#poo-flow-temporal-mrr-derivation-from-ascent
                         __tmp5369
                         _%owned-program2077%_
                         _%correspondence2330%_
                         _%bound2328%_
                         _%admission2221%_
                         _%snapshot2215%_
                         _%candidate2217%_
                         _%receipt2219%_
                         _%steps2072%_
                         _%max-nodes2074%_
                         _%node-bindings2262%_
                         _%output2136%_
                         _%source-bindings2298%_
                         _%journal2138%_)))
                     (_%support2334%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref _%joint2332%_ 'support)))
                     (_%ht2337%_
                      (let ()
                        (declare (not safe))
                        (make-hash-table__%
                         '#f
                         '18
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value))))
                (let ()
                  (declare (not safe))
                  (__hash-put!
                   _%ht2337%_
                   'schema
                   '"poo-flow.temporal-derivation-admit-result.v1"))
                (let ()
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'abiVersion '1))
                (let ((__tmp5370
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%joint2332%_
                          'semantic-digest))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'bindingDigest __tmp5370))
                (let ((__tmp5371
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%admission2221%_
                          'proof-digest))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'proofDigest __tmp5371))
                (let ((__tmp5372
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%owned-program2077%_
                          'catalog-digest))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'catalogDigest __tmp5372))
                (let ((__tmp5373
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%owned-program2077%_
                          'generation))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'generation __tmp5373))
                (let ((__tmp5374
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%joint2332%_
                          'derivation-identity))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'derivationIdentity __tmp5374))
                (let ((__tmp5375
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref _%joint2332%_ 'rule-identity))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'ruleIdentity __tmp5375))
                (let ((__tmp5376
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref _%joint2332%_ 'node-bindings))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'nodeBindings __tmp5376))
                (let ((__tmp5377
                       (let ((_%ht2340%_
                              (let ()
                                (declare (not safe))
                                (make-hash-table__%
                                 '#f
                                 '5
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value))))
                         (let ((__tmp5378
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%support2334%_
                                   'identity))))
                           (declare (not safe))
                           (__hash-put! _%ht2340%_ 'identity __tmp5378))
                         (let ((__tmp5379
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%support2334%_
                                   'conclusion-identity))))
                           (declare (not safe))
                           (__hash-put! _%ht2340%_ 'conclusion __tmp5379))
                         (let ((__tmp5380
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%support2334%_
                                   'proof-identity))))
                           (declare (not safe))
                           (__hash-put! _%ht2340%_ 'proof __tmp5380))
                         (let ()
                           (declare (not safe))
                           (__hash-put! _%ht2340%_ 'parents '()))
                         (let ((__tmp5381
                                (map (lambda (_%p2343%_)
                                       (let ((_%ht2345%_
                                              (let ()
                                                (declare (not safe))
                                                (make-hash-table__%
                                                 '#f
                                                 '2
                                                 absent-value
                                                 absent-value
                                                 absent-value
                                                 absent-value
                                                 absent-value
                                                 absent-value
                                                 absent-value))))
                                         (let ((__tmp5382
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%p2343%_
                                                   'subject-identity))))
                                           (declare (not safe))
                                           (__hash-put!
                                            _%ht2345%_
                                            'subject
                                            __tmp5382))
                                         (let ((__tmp5383
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%p2343%_
                                                   'revision-identity))))
                                           (declare (not safe))
                                           (__hash-put!
                                            _%ht2345%_
                                            'revision
                                            __tmp5383))
                                         _%ht2345%_))
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%support2334%_
                                        'premises)))))
                           (declare (not safe))
                           (__hash-put! _%ht2340%_ 'premises __tmp5381))
                         _%ht2340%_)))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'support __tmp5377))
                (let ((__tmp5384
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%admission2221%_
                          'proof-admitted?))))
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'proofAdmitted __tmp5384))
                (let ((__tmp5385
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%joint2332%_
                          'derivation-correspondence-verified?))))
                  (declare (not safe))
                  (__hash-put!
                   _%ht2337%_
                   'derivationCorrespondenceVerified
                   __tmp5385))
                (let ((__tmp5386
                       (let ()
                         (declare (not safe))
                         (clan/poo/object#.ref
                          _%joint2332%_
                          'mrr-rule-equivalence-verified?))))
                  (declare (not safe))
                  (__hash-put!
                   _%ht2337%_
                   'mrrRuleEquivalenceVerified
                   __tmp5386))
                (let ()
                  (declare (not safe))
                  (__hash-put!
                   _%ht2337%_
                   'trustBasis
                   '"host-declared-source-relative-native-proof"))
                (let ()
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'sourceAuthenticated '#f))
                (let ()
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'selectionAdmitted '#f))
                (let ()
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'actionAuthorized '#f))
                (let ()
                  (declare (not safe))
                  (__hash-put! _%ht2337%_ 'durable '#f))
                _%ht2337%_))))))))
